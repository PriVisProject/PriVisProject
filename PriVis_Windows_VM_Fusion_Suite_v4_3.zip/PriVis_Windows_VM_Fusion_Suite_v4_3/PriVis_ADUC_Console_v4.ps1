﻿<#
.SYNOPSIS
    PriVis ADUC MMC Console - Universal Governance Edition (v4.3)
.DESCRIPTION
    Self-contained Windows Forms (.NET Framework) MMC-style Active Directory Users and Computers
    console supporting:
      1. Built-in Sandbox Lab Dataset (Eagle Business Solutions)
      2. Dynamic Excel (.xlsx/.xls) & CSV Folder Import (any organization's data)
      3. Live Active Directory Domain & Local Windows Directory Scanning & Remediation
      4. Custom Department OU Palette & Severity Alert Color Mapping
      5. Policy-Driven + Heuristic Least-Privilege Risk Engine & One-Click Remediation
#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ==============================================================================
# 1. DEFAULT EMBEDDED SANDBOX DATASET & DYNAMIC COLOR PALETTE ENGINE
# ==============================================================================
$script:AuditDate   = Get-Date
$script:DomainFQDN  = "eaglebusiness.local"
$script:RootOUName  = "Eagle Business Solutions"
$script:DataSource  = "Built-in Sandbox Lab (Eagle Business Solutions)"
$script:LiveADMode  = $false
$script:HasADModule = $null -ne (Get-Module -ListAvailable -Name ActiveDirectory)

# Preset department colors + automatic pastel palette for any custom organization OUs
$script:BaseDeptColors = @{
    "IT"               = [System.Drawing.Color]::FromArgb(233, 213, 255) # Purple tint
    "Operations"       = [System.Drawing.Color]::FromArgb(229, 231, 235) # Gray tint
    "Finance"          = [System.Drawing.Color]::FromArgb(187, 247, 208) # Green tint
    "Marketing"        = [System.Drawing.Color]::FromArgb(191, 219, 254) # Blue tint
    "HR"               = [System.Drawing.Color]::FromArgb(165, 243, 252) # Turquoise tint
    "Customer Support" = [System.Drawing.Color]::FromArgb(204, 251, 241) # Teal tint
    "Sales"            = [System.Drawing.Color]::FromArgb(254, 243, 199) # Amber tint
    "Security Groups"  = [System.Drawing.Color]::FromArgb(231, 216, 201) # Brown tint
}

$script:DynamicPalette = @(
    [System.Drawing.Color]::FromArgb(233, 213, 255), # Purple
    [System.Drawing.Color]::FromArgb(229, 231, 235), # Gray
    [System.Drawing.Color]::FromArgb(187, 247, 208), # Green
    [System.Drawing.Color]::FromArgb(191, 219, 254), # Blue
    [System.Drawing.Color]::FromArgb(165, 243, 252), # Turquoise
    [System.Drawing.Color]::FromArgb(204, 251, 241), # Teal
    [System.Drawing.Color]::FromArgb(254, 243, 199), # Amber
    [System.Drawing.Color]::FromArgb(243, 232, 255), # Lavender
    [System.Drawing.Color]::FromArgb(224, 242, 254), # Sky
    [System.Drawing.Color]::FromArgb(231, 216, 201)  # Brown
)
$script:ColorNames = @("Purple", "Gray", "Green", "Blue", "Turquoise", "Teal", "Amber", "Lavender", "Sky", "Brown")
$script:DeptColors = @{}
$script:DeptColorLabels = @{}

function Rebuild-DepartmentPalette {
    $script:DeptColors = @{}
    $script:DeptColorLabels = @{}
    $idx = 0
    $uniqueDepts = @($script:Users | ForEach-Object { $_.dept } | Where-Object { $_ } | Select-Object -Unique)
    foreach ($d in $uniqueDepts) {
        if ($script:BaseDeptColors.ContainsKey($d)) {
            $script:DeptColors[$d] = $script:BaseDeptColors[$d]
            $labelMap = @{
                "IT"               = "Purple"
                "Operations"       = "Gray"
                "Finance"          = "Green"
                "Marketing"        = "Blue"
                "HR"               = "Turquoise"
                "Customer Support" = "Teal"
                "Sales"            = "Amber"
                "Security Groups"  = "Brown"
            }
            $script:DeptColorLabels[$d] = $labelMap[$d]
        } else {
            $cIdx = $idx % $script:DynamicPalette.Count
            $script:DeptColors[$d] = $script:DynamicPalette[$cIdx]
            $script:DeptColorLabels[$d] = $script:ColorNames[$cIdx]
            $idx++
        }
    }
    $script:DeptColors["Security Groups"] = [System.Drawing.Color]::FromArgb(231, 216, 201)
    $script:DeptColorLabels["Security Groups"] = "Brown"
}

$RawUsersJson = @'
[
  {
    "user_id": "U001",
    "name": "Maya Torres",
    "sam": "mtorres",
    "dept": "Customer Support",
    "role": "Support Rep",
    "worker_type": "Part-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U002",
    "name": "Alex Chen",
    "sam": "achen",
    "dept": "IT",
    "role": "IT Admin",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U003",
    "name": "Taylor Morgan",
    "sam": "tmorgan",
    "dept": "IT",
    "role": "IT Contractor",
    "worker_type": "Contractor",
    "enabled": true,
    "end_date": "2026-11-01"
  },
  {
    "user_id": "U004",
    "name": "Jordan Lee",
    "sam": "jlee",
    "dept": "Customer Support",
    "role": "Support Rep",
    "worker_type": "Part-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U005",
    "name": "Sam Patel",
    "sam": "spatel",
    "dept": "Sales",
    "role": "Sales Rep",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U006",
    "name": "Chris Rivera",
    "sam": "crivera",
    "dept": "Finance",
    "role": "Finance Analyst",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U007",
    "name": "Renee Brooks",
    "sam": "rbrooks",
    "dept": "Finance",
    "role": "Payroll Specialist",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U008",
    "name": "Avery Kim",
    "sam": "akim",
    "dept": "Sales",
    "role": "Sales Manager",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U009",
    "name": "Morgan Ellis",
    "sam": "mellis",
    "dept": "HR",
    "role": "HR Coordinator",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U010",
    "name": "Jamie Price",
    "sam": "jprice",
    "dept": "IT",
    "role": "IT Support",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U011",
    "name": "Casey Nguyen",
    "sam": "cnguyen",
    "dept": "Finance",
    "role": "Finance Manager",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U012",
    "name": "Devon Reed",
    "sam": "dreed",
    "dept": "Sales",
    "role": "Sales Rep",
    "worker_type": "Former Employee",
    "enabled": false,
    "end_date": "2026-09-30"
  }
]
'@

$RawGroupsJson = @'
[
  {
    "group_id": "G001",
    "group_name": "Customer-Support",
    "risk_level": "Low",
    "resource_scope": "CRM - customer records",
    "description": "Read and update routine customer support tickets"
  },
  {
    "group_id": "G002",
    "group_name": "Payroll-Editors",
    "risk_level": "High",
    "resource_scope": "Payroll application",
    "description": "Edit payroll records and payroll adjustments"
  },
  {
    "group_id": "G003",
    "group_name": "Server-Admins",
    "risk_level": "Critical",
    "resource_scope": "Server administration",
    "description": "Privileged access to managed company servers"
  },
  {
    "group_id": "G004",
    "group_name": "Sales-Reports",
    "risk_level": "Low",
    "resource_scope": "Sales reporting portal",
    "description": "Read and create standard sales reports"
  },
  {
    "group_id": "G005",
    "group_name": "Finance-Reports",
    "risk_level": "Medium",
    "resource_scope": "Financial reporting portal",
    "description": "Read internal financial reports"
  },
  {
    "group_id": "G006",
    "group_name": "HR-Records",
    "risk_level": "High",
    "resource_scope": "HR records application",
    "description": "View and update confidential employee records"
  },
  {
    "group_id": "G007",
    "group_name": "Helpdesk-Reset",
    "risk_level": "High",
    "resource_scope": "IT service desk",
    "description": "Reset company account credentials within approved scope"
  },
  {
    "group_id": "G008",
    "group_name": "All-Employees",
    "risk_level": "Low",
    "resource_scope": "Company intranet",
    "description": "Read internal general company resources"
  }
]
'@

$RawMembJson = @'
[
  {
    "user_id": "U001",
    "group_id": "G001",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U001",
    "group_id": "G002",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U001",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U002",
    "group_id": "G003",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U002",
    "group_id": "G007",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U002",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U003",
    "group_id": "G003",
    "approval_status": "Missing",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U003",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U004",
    "group_id": "G001",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U004",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U005",
    "group_id": "G004",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U005",
    "group_id": "G005",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U005",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U006",
    "group_id": "G005",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U006",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U007",
    "group_id": "G002",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U007",
    "group_id": "G005",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U007",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U008",
    "group_id": "G004",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U008",
    "group_id": "G005",
    "approval_status": "Approved",
    "approval_ticket": "APR-2026-014",
    "approval_expires": "2026-12-15"
  },
  {
    "user_id": "U008",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U009",
    "group_id": "G006",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U009",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U010",
    "group_id": "G007",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U010",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U011",
    "group_id": "G002",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U011",
    "group_id": "G005",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U011",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U012",
    "group_id": "G004",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U012",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  }
]
'@

$RawPolicyJson = @'
[
  {
    "role": "Support Rep",
    "group_id": "G001",
    "access_decision": "Allowed",
    "policy_reason": "Support team requires customer ticket access"
  },
  {
    "role": "Support Rep",
    "group_id": "G002",
    "access_decision": "Denied",
    "policy_reason": "Support role must not edit payroll"
  },
  {
    "role": "Support Rep",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet for all current workers"
  },
  {
    "role": "IT Admin",
    "group_id": "G003",
    "access_decision": "Allowed",
    "policy_reason": "IT administrator has approved server administration duties"
  },
  {
    "role": "IT Admin",
    "group_id": "G007",
    "access_decision": "Allowed",
    "policy_reason": "IT administrator can manage service desk credential resets"
  },
  {
    "role": "IT Admin",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "IT Contractor",
    "group_id": "G003",
    "access_decision": "Approval Required",
    "policy_reason": "Privileged server access requires a time-limited exception"
  },
  {
    "role": "IT Contractor",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet available during active contract"
  },
  {
    "role": "Sales Rep",
    "group_id": "G004",
    "access_decision": "Allowed",
    "policy_reason": "Sales representatives require sales reporting"
  },
  {
    "role": "Sales Rep",
    "group_id": "G005",
    "access_decision": "Denied",
    "policy_reason": "Sales representatives should not access financial reporting"
  },
  {
    "role": "Sales Rep",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "Finance Analyst",
    "group_id": "G005",
    "access_decision": "Allowed",
    "policy_reason": "Finance analysts require financial reports"
  },
  {
    "role": "Finance Analyst",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "Payroll Specialist",
    "group_id": "G002",
    "access_decision": "Allowed",
    "policy_reason": "Payroll specialists maintain payroll data"
  },
  {
    "role": "Payroll Specialist",
    "group_id": "G005",
    "access_decision": "Allowed",
    "policy_reason": "Payroll specialists can view financial reports"
  },
  {
    "role": "Payroll Specialist",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "Sales Manager",
    "group_id": "G004",
    "access_decision": "Allowed",
    "policy_reason": "Sales managers require sales reporting"
  },
  {
    "role": "Sales Manager",
    "group_id": "G005",
    "access_decision": "Approval Required",
    "policy_reason": "Finance reporting for Sales managers requires documented approval"
  },
  {
    "role": "Sales Manager",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "HR Coordinator",
    "group_id": "G006",
    "access_decision": "Allowed",
    "policy_reason": "HR coordinators manage employee records"
  },
  {
    "role": "HR Coordinator",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "IT Support",
    "group_id": "G007",
    "access_decision": "Allowed",
    "policy_reason": "IT support staff perform credential resets"
  },
  {
    "role": "IT Support",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "Finance Manager",
    "group_id": "G002",
    "access_decision": "Allowed",
    "policy_reason": "Finance managers may manage payroll operations"
  },
  {
    "role": "Finance Manager",
    "group_id": "G005",
    "access_decision": "Allowed",
    "policy_reason": "Finance managers require financial reports"
  },
  {
    "role": "Finance Manager",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  }
]
'@

function Reset-LabState {
    $script:AuditDate        = [datetime]"2026-11-14"
    $script:DomainFQDN       = "eaglebusiness.local"
    $script:RootOUName       = "Eagle Business Solutions"
    $script:DataSource       = "Built-in Sandbox Lab (Eagle Business Solutions)"
    $script:LiveADMode       = $false
    $script:LocalWindowsMode = $false

    $script:Users       = [object[]]($RawUsersJson | ConvertFrom-Json)
    $script:Groups      = [object[]]($RawGroupsJson | ConvertFrom-Json)
    $parsedMemb         = [object[]]($RawMembJson | ConvertFrom-Json)
    $script:Memberships = New-Object System.Collections.ArrayList
    foreach ($item in $parsedMemb) { [void]$script:Memberships.Add($item) }
    $script:Policies    = [object[]]($RawPolicyJson | ConvertFrom-Json)
    Rebuild-DepartmentPalette
}
Reset-LabState

# ==============================================================================
# 2. UNIVERSAL EXCEL / CSV IMPORTER (COM EXCEL + CSV FOLDER FALLBACK)
# ==============================================================================
function ConvertTo-BoolSafe {
    param($Val)
    if ($null -eq $Val) { return $true }
    $s = $Val.ToString().Trim().ToLower()
    if ($s -in @("false", "0", "no", "disabled", "inactive")) { return $false }
    return $true
}

function ConvertTo-DateStrSafe {
    param($Val)
    if ($null -eq $Val -or $Val.ToString().Trim() -eq "") { return $null }
    try {
        if ($Val -is [double] -or $Val -is [int]) {
            return ([datetime]::FromOADate([double]$Val)).ToString("yyyy-MM-dd")
        }
        return ([datetime]$Val).ToString("yyyy-MM-dd")
    } catch {
        return $null
    }
}

function Load-NormalizedTables {
    param($RawUsers, $RawGroups, $RawMembs, $RawPolicies, [string]$SourceLabel)

    $newUsers = @()
    $uCounter = 1
    foreach ($r in $RawUsers) {
        $name = if ($r.name) { $r.name } elseif ($r.display_name) { $r.display_name } elseif ($r.DisplayName) { $r.DisplayName } else { $null }
        $sam  = if ($r.sam_account_name) { $r.sam_account_name } elseif ($r.sam) { $r.sam } elseif ($r.SamAccountName) { $r.SamAccountName } else { $null }
        if (-not $name -and -not $sam) { continue }
        if (-not $name) { $name = $sam }
        if (-not $sam)  { $sam = ($name -replace '\s+', '.').ToLower() }

        $uid  = if ($r.user_id) { $r.user_id.ToString().Trim() } else { "U{0:D3}" -f $uCounter }
        $dept = if ($r.department) { $r.department.ToString().Trim() } elseif ($r.dept) { $r.dept.ToString().Trim() } else { "General" }
        $role = if ($r.role) { $r.role.ToString().Trim() } elseif ($r.title) { $r.title.ToString().Trim() } else { "Standard User" }
        $wt   = if ($r.worker_type) { $r.worker_type.ToString().Trim() } else { "Full-Time" }
        $en   = ConvertTo-BoolSafe $r.enabled
        $ed   = ConvertTo-DateStrSafe $r.end_date

        $newUsers += [PSCustomObject]@{
            user_id = $uid; name = $name.ToString().Trim(); sam = $sam.ToString().Trim();
            dept = $dept; role = $role; worker_type = $wt; enabled = $en; end_date = $ed
        }
        $uCounter++
    }

    $newGroups = @()
    $gCounter = 1
    foreach ($g in $RawGroups) {
        $gName = if ($g.group_name) { $g.group_name } elseif ($g.name) { $g.name } elseif ($g.Name) { $g.Name } else { $null }
        if (-not $gName) { continue }
        $gid   = if ($g.group_id) { $g.group_id.ToString().Trim() } else { "G{0:D3}" -f $gCounter }
        $rl    = if ($g.risk_level) { $g.risk_level.ToString().Trim() } else {
            if ($gName -match "(?i)admin|domain|enterprise|schema|root|server") { "Critical" }
            elseif ($gName -match "(?i)payroll|hr|finance|secret|exec|reset|security") { "High" }
            else { "Low" }
        }
        $scope = if ($g.resource_scope) { $g.resource_scope.ToString().Trim() } else { "Directory Security Group" }
        $desc  = if ($g.description) { $g.description.ToString().Trim() } else { $scope }

        $newGroups += [PSCustomObject]@{
            group_id = $gid; group_name = $gName.ToString().Trim(); risk_level = $rl; resource_scope = $scope; description = $desc
        }
        $gCounter++
    }

    $newMembs = New-Object System.Collections.ArrayList
    foreach ($m in $RawMembs) {
        $uRef = if ($m.user_id) { $m.user_id.ToString().Trim() } elseif ($m.sam) { $m.sam.ToString().Trim() } elseif ($m.sam_account_name) { $m.sam_account_name.ToString().Trim() } else { $null }
        $gRef = if ($m.group_id) { $m.group_id.ToString().Trim() } elseif ($m.group_name) { $m.group_name.ToString().Trim() } else { $null }
        if (-not $uRef -or -not $gRef) { continue }

        $matchedUser = $newUsers | Where-Object { $_.user_id -eq $uRef -or $_.sam -eq $uRef } | Select-Object -First 1
        $matchedGrp  = $newGroups | Where-Object { $_.group_id -eq $gRef -or $_.group_name -eq $gRef } | Select-Object -First 1
        if ($matchedUser -and $matchedGrp) {
            [void]$newMembs.Add([PSCustomObject]@{
                user_id          = $matchedUser.user_id
                group_id         = $matchedGrp.group_id
                approval_status  = if ($m.approval_status) { $m.approval_status.ToString().Trim() } else { "Not Required" }
                approval_ticket  = if ($m.approval_ticket) { $m.approval_ticket.ToString().Trim() } else { $null }
                approval_expires = ConvertTo-DateStrSafe $m.approval_expires
            })
        }
    }

    $newPolicies = @()
    foreach ($p in $RawPolicies) {
        if (-not $p.role) { continue }
        $gRef = if ($p.group_id) { $p.group_id.ToString().Trim() } elseif ($p.group_name) { $p.group_name.ToString().Trim() } else { $null }
        $matchedGrp = $newGroups | Where-Object { $_.group_id -eq $gRef -or $_.group_name -eq $gRef } | Select-Object -First 1
        $targetGid = if ($matchedGrp) { $matchedGrp.group_id } else { $gRef }
        if ($targetGid) {
            $newPolicies += [PSCustomObject]@{
                role            = $p.role.ToString().Trim()
                group_id        = $targetGid
                access_decision = if ($p.access_decision) { $p.access_decision.ToString().Trim() } else { "Allowed" }
                policy_reason   = if ($p.policy_reason) { $p.policy_reason.ToString().Trim() } else { "Imported policy rule" }
            }
        }
    }

    if ($newUsers.Count -eq 0) {
        throw "No valid user records found in the imported file(s). Ensure columns like 'name' or 'sam_account_name' exist."
    }

    $script:Users       = [object[]]$newUsers
    $script:Groups      = [object[]]$newGroups
    $script:Memberships = $newMembs
    $script:Policies    = [object[]]$newPolicies
    $script:AuditDate   = Get-Date
    $script:LiveADMode  = $false
    $script:DataSource  = $SourceLabel
    $script:DomainFQDN  = "imported.local"
    $script:RootOUName  = [System.IO.Path]::GetFileNameWithoutExtension($SourceLabel)
    Rebuild-DepartmentPalette
}

function Import-FromExcelWorkbook {
    param([string]$FilePath)
    $excel = $null
    $wb = $null
    try {
        $excel = New-Object -ComObject Excel.Application
        $excel.Visible = $false
        $excel.DisplayAlerts = $false
        $wb = $excel.Workbooks.Open($FilePath, $null, $true)

        $sheetsData = @{}
        foreach ($ws in $wb.Worksheets) {
            $sName = $ws.Name.ToLower().Trim()
            $usedRange = $ws.UsedRange
            $rows = $usedRange.Rows.Count
            $cols = $usedRange.Columns.Count
            if ($rows -lt 2 -or $cols -lt 1) { continue }

            $vals = $usedRange.Value2
            $headers = @()
            for ($c = 1; $c -le $cols; $c++) {
                $h = if ($vals[1, $c]) { $vals[1, $c].ToString().Trim().ToLower() -replace '\s+', '_' } else { "col_$c" }
                $headers += $h
            }

            $records = @()
            for ($r = 2; $r -le $rows; $r++) {
                $obj = [ordered]@{}
                $hasData = $false
                for ($c = 1; $c -le $cols; $c++) {
                    $cellVal = $vals[$r, $c]
                    if ($null -ne $cellVal -and $cellVal.ToString().Trim() -ne "") { $hasData = $true }
                    $obj[$headers[$c - 1]] = $cellVal
                }
                if ($hasData) { $records += [PSCustomObject]$obj }
            }
            $sheetsData[$sName] = $records
        }

        $uRows = if ($sheetsData.ContainsKey("users")) { $sheetsData["users"] } else { ($sheetsData.Values | Select-Object -First 1) }
        $gRows = if ($sheetsData.ContainsKey("groups")) { $sheetsData["groups"] } else { @() }
        $mRows = if ($sheetsData.ContainsKey("memberships")) { $sheetsData["memberships"] } else { @() }
        $pRows = if ($sheetsData.ContainsKey("access_policy")) { $sheetsData["access_policy"] } elseif ($sheetsData.ContainsKey("policies")) { $sheetsData["policies"] } else { @() }

        Load-NormalizedTables -RawUsers $uRows -RawGroups $gRows -RawMembs $mRows -RawPolicies $pRows -SourceLabel ([System.IO.Path]::GetFileName($FilePath))
    }
    finally {
        if ($wb) { $wb.Close($false) | Out-Null }
        if ($excel) { $excel.Quit() | Out-Null; [System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel) | Out-Null }
    }
}

function Import-FromCsvFiles {
    param([string[]]$CsvPaths)
    $uRows = @(); $gRows = @(); $mRows = @(); $pRows = @()
    foreach ($p in $CsvPaths) {
        $fn = [System.IO.Path]::GetFileNameWithoutExtension($p).ToLower()
        $rows = Import-Csv -Path $p
        if ($fn -match "group") { $gRows += $rows }
        elseif ($fn -match "member") { $mRows += $rows }
        elseif ($fn -match "polic") { $pRows += $rows }
        else { $uRows += $rows }
    }
    $label = if ($CsvPaths.Count -eq 1) { [System.IO.Path]::GetFileName($CsvPaths[0]) } else { "CSV Bundle ($($CsvPaths.Count) files)" }
    Load-NormalizedTables -RawUsers $uRows -RawGroups $gRows -RawMembs $mRows -RawPolicies $pRows -SourceLabel $label
}

function Export-SampleTemplateCsvs {
    param([string]$FolderPath)
    $script:Users | Select-Object user_id, name, @{N='sam_account_name';E={$_.sam}}, @{N='department';E={$_.dept}}, role, worker_type, enabled, end_date | Export-Csv -Path (Join-Path $FolderPath "users.csv") -NoTypeInformation
    $script:Groups | Select-Object group_id, group_name, risk_level, resource_scope, description | Export-Csv -Path (Join-Path $FolderPath "groups.csv") -NoTypeInformation
    $script:Memberships | Select-Object user_id, group_id, approval_status, approval_ticket, approval_expires | Export-Csv -Path (Join-Path $FolderPath "memberships.csv") -NoTypeInformation
    $script:Policies | Select-Object role, group_id, access_decision, policy_reason | Export-Csv -Path (Join-Path $FolderPath "access_policy.csv") -NoTypeInformation
}

# ==============================================================================
# 3. LIVE DIRECTORY SCANNER (ACTIVE DIRECTORY DOMAIN OR LOCAL WINDOWS SAM)
# ==============================================================================
$script:LocalWindowsMode = $false

function Invoke-LiveADDomainScan {
    $compSys = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
    $isDomainJoined = ($null -ne $compSys -and $compSys.PartOfDomain)

    if ($isDomainJoined -and $script:HasADModule) {
        try {
            Import-Module ActiveDirectory -ErrorAction Stop
            $domainObj = Get-ADDomain -ErrorAction Stop
            $adUsers   = @(Get-ADUser -Filter * -Properties DisplayName, SamAccountName, Department, Title, EmployeeType, Enabled, AccountExpirationDate, DistinguishedName, MemberOf -ErrorAction Stop)
            $adGroups  = @(Get-ADGroup -Filter "GroupCategory -eq 'Security'" -Properties Name, Description, DistinguishedName -ErrorAction Stop)

            $newUsers  = @()
            $newGroups = @()
            $newMembs  = New-Object System.Collections.ArrayList
            $grpDnMap  = @{}

            $gIdx = 1
            foreach ($g in $adGroups) {
                $gid = "G{0:D3}" -f $gIdx
                $rl = if ($g.Name -match "(?i)domain admins|enterprise admins|schema admins|administrators|server") { "Critical" }
                      elseif ($g.Name -match "(?i)account operators|backup|payroll|hr|finance|security|reset") { "High" }
                      elseif ($g.Name -match "(?i)remote|vpn|manager|report") { "Medium" }
                      else { "Low" }
                $gObj = [PSCustomObject]@{
                    group_id       = $gid
                    group_name     = $g.Name
                    risk_level     = $rl
                    resource_scope = "Active Directory Security Group"
                    description    = if ($g.Description) { $g.Description } else { $g.DistinguishedName }
                }
                $newGroups += $gObj
                $grpDnMap[$g.DistinguishedName] = $gid
                $gIdx++
            }

            $uIdx = 1
            foreach ($u in $adUsers) {
                $uid = "U{0:D3}" -f $uIdx
                $dept = $u.Department
                if (-not $dept -and $u.DistinguishedName -match "OU=([^,]+),") {
                    $dept = $Matches[1]
                }
                if (-not $dept) { $dept = "Domain Users" }

                $role = if ($u.Title) { $u.Title } else { "Domain User" }
                $wt   = if ($u.EmployeeType) { $u.EmployeeType } elseif ($u.AccountExpirationDate) { "Contractor" } else { "Full-Time" }
                $ed   = if ($u.AccountExpirationDate) { $u.AccountExpirationDate.ToString("yyyy-MM-dd") } else { $null }

                $newUsers += [PSCustomObject]@{
                    user_id     = $uid
                    name        = if ($u.DisplayName) { $u.DisplayName } else { $u.Name }
                    sam         = $u.SamAccountName
                    dept        = $dept
                    role        = $role
                    worker_type = $wt
                    enabled     = [bool]$u.Enabled
                    end_date    = $ed
                }

                if ($u.MemberOf) {
                    foreach ($dn in $u.MemberOf) {
                        if ($grpDnMap.ContainsKey($dn)) {
                            [void]$newMembs.Add([PSCustomObject]@{
                                user_id          = $uid
                                group_id         = $grpDnMap[$dn]
                                approval_status  = "Not Required"
                                approval_ticket  = $null
                                approval_expires = $null
                            })
                        }
                    }
                }
                $uIdx++
            }

            $script:Users            = [object[]]$newUsers
            $script:Groups           = [object[]]$newGroups
            $script:Memberships      = $newMembs
            $script:Policies         = @()
            $script:AuditDate        = Get-Date
            $script:DomainFQDN       = $domainObj.DNSRoot
            $script:RootOUName       = $domainObj.NetBIOSName
            $script:LiveADMode       = $true
            $script:LocalWindowsMode = $false
            $script:DataSource       = "Live Active Directory ($($domainObj.DNSRoot))"
            Rebuild-DepartmentPalette
            return
        } catch {
            # Fall through smoothly to Local Windows SAM scan
        }
    }

    $localUsers  = @(Get-LocalUser -ErrorAction Stop)
    $localGroups = @(Get-LocalGroup -ErrorAction Stop)

    $newUsers  = @()
    $newGroups = @()
    $newMembs  = New-Object System.Collections.ArrayList
    $grpNameMap = @{}

    $gIdx = 1
    foreach ($g in $localGroups) {
        $gid = "G{0:D3}" -f $gIdx
        $rl = if ($g.Name -match "(?i)^Administrators$|Hyper-V Administrators|Server Operators") { "Critical" }
              elseif ($g.Name -match "(?i)Remote Desktop Users|Power Users|Backup Operators|Cryptographic|Network Configuration") { "High" }
              elseif ($g.Name -match "(?i)Remote Management|Event Log|Performance") { "Medium" }
              else { "Low" }
        $newGroups += [PSCustomObject]@{
            group_id       = $gid
            group_name     = $g.Name
            risk_level     = $rl
            resource_scope = "Local Windows Security Group"
            description    = if ($g.Description) { $g.Description } else { "Built-in / Local Security Group" }
        }
        $grpNameMap[$g.Name] = $gid
        $gIdx++
    }

    $userGroupsLookup = @{}
    foreach ($g in $localGroups) {
        $members = @(Get-LocalGroupMember -Group $g.Name -ErrorAction SilentlyContinue)
        foreach ($m in $members) {
            if ($m.ObjectClass -eq "User") {
                $shortName = ($m.Name -split '\\')[-1]
                if (-not $userGroupsLookup.ContainsKey($shortName)) {
                    $userGroupsLookup[$shortName] = @()
                }
                $userGroupsLookup[$shortName] += $g.Name
            }
        }
    }

    $uIdx = 1
    foreach ($u in $localUsers) {
        $uid = "U{0:D3}" -f $uIdx
        $uGrps = if ($userGroupsLookup.ContainsKey($u.Name)) { $userGroupsLookup[$u.Name] } else { @() }

        $isBuiltInSystem = $u.Name -in @("Administrator", "Guest", "DefaultAccount", "WDAGUtilityAccount")
        $dept = if ($uGrps -contains "Administrators") { "Local Administrators" }
                elseif ($isBuiltInSystem) { "Built-In System Accounts" }
                else { "Standard Local Users" }

        $role = if ($uGrps -contains "Administrators") { "Local Administrator" }
                elseif ($isBuiltInSystem) { "Built-In System Account" }
                else { "Standard User" }

        $wt   = if ($u.AccountExpires) { "Temporary / Expiring" } elseif ($isBuiltInSystem) { "System Built-In" } else { "Local Account" }
        $ed   = if ($u.AccountExpires) { $u.AccountExpires.ToString("yyyy-MM-dd") } else { $null }

        $newUsers += [PSCustomObject]@{
            user_id     = $uid
            name        = if ($u.FullName) { $u.FullName } else { $u.Name }
            sam         = $u.Name
            dept        = $dept
            role        = $role
            worker_type = $wt
            enabled     = [bool]$u.Enabled
            end_date    = $ed
        }

        foreach ($gn in $uGrps) {
            if ($grpNameMap.ContainsKey($gn)) {
                [void]$newMembs.Add([PSCustomObject]@{
                    user_id          = $uid
                    group_id         = $grpNameMap[$gn]
                    approval_status  = "Not Required"
                    approval_ticket  = $null
                    approval_expires = $null
                })
            }
        }
        $uIdx++
    }

    $hostName = $env:COMPUTERNAME
    $script:Users            = [object[]]$newUsers
    $script:Groups           = [object[]]$newGroups
    $script:Memberships      = $newMembs
    $script:Policies         = @()
    $script:AuditDate        = Get-Date
    $script:DomainFQDN       = "$hostName.local"
    $script:RootOUName       = "$hostName (Local Machine)"
    $script:LiveADMode       = $false
    $script:LocalWindowsMode = $true
    $script:DataSource       = "Live Local Windows Directory ($hostName)"
    Rebuild-DepartmentPalette
}

# ==============================================================================
# 4. UNIVERSAL PRIVIS RISK & REMEDIATION ENGINE (WORKS ON ANY DATASET OR DOMAIN)
# ==============================================================================
function Get-UserRiskAnalysis {
    param($User)
    $uMembs = @($script:Memberships | Where-Object { $_.user_id -eq $User.user_id })
    $findings = @()
    $solutions = @()
    $severity = "Compliant"
    $sevRank = 0

    $isExpired = $false
    if ($User.end_date) {
        try {
            if ([datetime]$User.end_date -lt $script:AuditDate) { $isExpired = $true }
        } catch {}
    }

    if ($isExpired -and $User.enabled) {
        $findings += "CRITICAL: Account/contract end date ($($User.end_date)) passed, account still ENABLED."
        $solutions += "Disable '$($User.sam)' immediately (expired $($User.end_date)) and revoke active group memberships."
        if ($sevRank -lt 4) { $sevRank = 4; $severity = "Critical" }
    }

    if (-not $User.enabled -and $uMembs.Count -gt 0) {
        $gNames = ($uMembs | ForEach-Object {
            $gid = $_.group_id
            ($script:Groups | Where-Object { $_.group_id -eq $gid }).group_name
        }) -join ", "
        $findings += "LOW: Disabled account retains residual groups ($gNames)."
        $solutions += "Strip residual security groups ($gNames) from disabled account '$($User.sam)'."
        if ($sevRank -lt 1) { $sevRank = 1; $severity = "Low" }
    }

    foreach ($m in $uMembs) {
        $grp = $script:Groups | Where-Object { $_.group_id -eq $m.group_id }
        if (-not $grp) { continue }
        $pol = $script:Policies | Where-Object { $_.role -eq $User.role -and $_.group_id -eq $m.group_id }

        if ($pol) {
            if ($pol.access_decision -eq "Denied") {
                $r = if ($grp.risk_level -in @("High", "Critical")) { 3 } else { 2 }
                $lbl = if ($r -eq 3) { "HIGH" } else { "MEDIUM" }
                $findings += "${lbl}: Explicitly denied group $($grp.group_name) ($($pol.policy_reason))."
                $solutions += "Remove '$($User.sam)' from $($grp.group_name) ($($grp.group_id)); $($pol.policy_reason)."
                if ($sevRank -lt $r) { $sevRank = $r; $severity = if ($r -eq 3) { "High" } else { "Medium" } }
            }
            elseif ($pol.access_decision -eq "Approval Required") {
                $validExp = $false
                if ($m.approval_status -eq "Approved" -and $m.approval_expires) {
                    try { if ([datetime]$m.approval_expires -ge $script:AuditDate) { $validExp = $true } } catch {}
                }
                if (-not $validExp) {
                    $r = if ($grp.risk_level -eq "Critical") { 4 } else { 3 }
                    $lbl = if ($r -eq 4) { "CRITICAL" } else { "HIGH" }
                    $findings += "${lbl}: $($grp.group_name) requires valid approval (Status: $($m.approval_status))."
                    $solutions += "Revoke $($grp.group_name) from '$($User.sam)' until a valid time-bound approval ticket is recorded."
                    if ($sevRank -lt $r) { $sevRank = $r; $severity = if ($r -eq 4) { "Critical" } else { "High" } }
                }
            }
        }
        elseif ($script:Policies.Count -eq 0 -and $User.enabled) {
            if ($User.sam -eq "Guest") {
                $findings += "CRITICAL: Built-in Guest account is ENABLED."
                $solutions += "Disable the built-in 'Guest' account immediately."
                if ($sevRank -lt 4) { $sevRank = 4; $severity = "Critical" }
            }
            elseif ($grp.risk_level -eq "Critical" -and $User.dept -notmatch "(?i)^IT$|Infrastructure|Security|Admin" -and $User.role -notmatch "(?i)Admin|Engineer|Architect") {
                $findings += "CRITICAL: Non-IT user holds critical privileged group $($grp.group_name)."
                $solutions += "Remove non-IT account '$($User.sam)' from privileged group '$($grp.group_name)'."
                if ($sevRank -lt 4) { $sevRank = 4; $severity = "Critical" }
            }
            elseif ($grp.risk_level -eq "High" -and $User.worker_type -match "(?i)Contractor|Intern|Temp") {
                $findings += "HIGH: Temporary/contractor account holds high-risk group $($grp.group_name)."
                $solutions += "Remove contractor '$($User.sam)' from high-risk group '$($grp.group_name)' or apply time-bound expiration."
                if ($sevRank -lt 3) { $sevRank = 3; $severity = "High" }
            }
        }
    }

    $finalSolution = if ($solutions.Count -gt 0) {
        $solutions -join " "
    } else {
        "No remediation required. Access complies with least-privilege policy."
    }

    return [PSCustomObject]@{
        Severity = $severity
        SevRank  = $sevRank
        Findings = ($findings -join " | ")
        Solution = $finalSolution
    }
}

function Invoke-UserRemediation {
    param([string]$UserId)
    $u = $script:Users | Where-Object { $_.user_id -eq $UserId }
    if (-not $u) { return }

    $isExpired = $false
    if ($u.end_date) {
        try { if ([datetime]$u.end_date -lt $script:AuditDate) { $isExpired = $true } } catch {}
    }

    if (($isExpired -or $u.sam -eq "Guest") -and $u.enabled) {
        $u.enabled = $false
        $toRemove = @($script:Memberships | Where-Object { $_.user_id -eq $UserId })
        foreach ($m in $toRemove) {
            $grp = $script:Groups | Where-Object { $_.group_id -eq $m.group_id }
            if ($script:LiveADMode -and $script:HasADModule -and $grp) {
                Remove-ADGroupMember -Identity $grp.group_name -Members $u.sam -Confirm:$false -ErrorAction SilentlyContinue
            } elseif ($script:LocalWindowsMode -and $grp) {
                Remove-LocalGroupMember -Group $grp.group_name -Member $u.sam -ErrorAction SilentlyContinue
            }
            [void]$script:Memberships.Remove($m)
        }
        if ($script:LiveADMode -and $script:HasADModule) {
            Disable-ADAccount -Identity $u.sam -ErrorAction SilentlyContinue
        } elseif ($script:LocalWindowsMode) {
            Disable-LocalUser -Name $u.sam -ErrorAction SilentlyContinue
        }
        return
    }

    if (-not $u.enabled) {
        $toRemove = @($script:Memberships | Where-Object { $_.user_id -eq $UserId })
        foreach ($m in $toRemove) {
            $grp = $script:Groups | Where-Object { $_.group_id -eq $m.group_id }
            if ($script:LiveADMode -and $script:HasADModule -and $grp) {
                Remove-ADGroupMember -Identity $grp.group_name -Members $u.sam -Confirm:$false -ErrorAction SilentlyContinue
            } elseif ($script:LocalWindowsMode -and $grp) {
                Remove-LocalGroupMember -Group $grp.group_name -Member $u.sam -ErrorAction SilentlyContinue
            }
            [void]$script:Memberships.Remove($m)
        }
        return
    }

    $uMembs = @($script:Memberships | Where-Object { $_.user_id -eq $UserId })
    foreach ($m in $uMembs) {
        $grp = $script:Groups | Where-Object { $_.group_id -eq $m.group_id }
        $pol = $script:Policies | Where-Object { $_.role -eq $u.role -and $_.group_id -eq $m.group_id }
        $shouldRemove = $false

        if ($pol) {
            if ($pol.access_decision -eq "Denied") { $shouldRemove = $true }
            elseif ($pol.access_decision -eq "Approval Required") {
                $validExp = $false
                if ($m.approval_status -eq "Approved" -and $m.approval_expires) {
                    try { if ([datetime]$m.approval_expires -ge $script:AuditDate) { $validExp = $true } } catch {}
                }
                if (-not $validExp) { $shouldRemove = $true }
            }
        }
        elseif ($script:Policies.Count -eq 0 -and $grp) {
            if ($grp.risk_level -eq "Critical" -and $u.dept -notmatch "(?i)^IT$|Infrastructure|Security|Admin" -and $u.role -notmatch "(?i)Admin|Engineer|Architect") {
                $shouldRemove = $true
            }
            elseif ($grp.risk_level -eq "High" -and $u.worker_type -match "(?i)Contractor|Intern|Temp") {
                $shouldRemove = $true
            }
        }

        if ($shouldRemove) {
            if ($script:LiveADMode -and $script:HasADModule -and $grp) {
                Remove-ADGroupMember -Identity $grp.group_name -Members $u.sam -Confirm:$false -ErrorAction SilentlyContinue
            }
            [void]$script:Memberships.Remove($m)
        }
    }
}

# ==============================================================================
# 5. BUILD TRADITIONAL WINDOWS MMC 3.0 / ADUC DESKTOP FORM
# ==============================================================================
$form = New-Object System.Windows.Forms.Form
$form.Text = "Active Directory Users and Computers - [eaglebusiness.local] (PriVis Universal Governance Edition)"
$form.Size = New-Object System.Drawing.Size(1340, 820)
$form.MinimumSize = New-Object System.Drawing.Size(1120, 680)
$form.StartPosition = "CenterScreen"
$form.WindowState = "Maximized"
$form.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$form.BackColor = [System.Drawing.SystemColors]::Control

$menuStrip = New-Object System.Windows.Forms.MenuStrip
$menuStrip.Dock = "Top"
$menuStrip.BackColor = [System.Drawing.SystemColors]::MenuBar
$menuStrip.Padding = New-Object System.Windows.Forms.Padding(6, 2, 0, 2)

$menuFile = New-Object System.Windows.Forms.ToolStripMenuItem("&File")
$miImportExcel  = New-Object System.Windows.Forms.ToolStripMenuItem("Import Organization Excel Workbook (.xlsx/.xls)...")
$miImportCsv    = New-Object System.Windows.Forms.ToolStripMenuItem("Import Organization CSV Files (.csv)...")
$miScanLiveAD   = New-Object System.Windows.Forms.ToolStripMenuItem("Scan Live Active Directory Domain / Local Windows Accounts")
$miExportTpl    = New-Object System.Windows.Forms.ToolStripMenuItem("Export Blank/Sample CSV Schema Templates...")
$miExportPS     = New-Object System.Windows.Forms.ToolStripMenuItem("Export Remediation PowerShell Script (.ps1)...")
$miResetLab     = New-Object System.Windows.Forms.ToolStripMenuItem("Reset to Built-In Sandbox Dataset")
$miExit         = New-Object System.Windows.Forms.ToolStripMenuItem("E&xit")
[void]$menuFile.DropDownItems.AddRange(@(
    $miImportExcel,
    $miImportCsv,
    $miScanLiveAD,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $miExportTpl,
    $miExportPS,
    $miResetLab,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $miExit
))

$menuAction = New-Object System.Windows.Forms.ToolStripMenuItem("&Action")
$miRemediateSel = New-Object System.Windows.Forms.ToolStripMenuItem("Apply PriVis Solution to Selected User")
$miRemediateAll = New-Object System.Windows.Forms.ToolStripMenuItem("Remediate All At-Risk Accounts Now")
[void]$menuAction.DropDownItems.AddRange(@($miRemediateSel, $miRemediateAll))

$menuView = New-Object System.Windows.Forms.ToolStripMenuItem("&View")
$miShowAll = New-Object System.Windows.Forms.ToolStripMenuItem("Select Root Container (All Departmental OUs)")
[void]$menuView.DropDownItems.Add($miShowAll)

$menuHelp = New-Object System.Windows.Forms.ToolStripMenuItem("&Help")
$miAbout = New-Object System.Windows.Forms.ToolStripMenuItem("About PriVis Universal ADUC Console...")
[void]$menuHelp.DropDownItems.Add($miAbout)

[void]$menuStrip.Items.AddRange(@($menuFile, $menuAction, $menuView, $menuHelp))
$form.MainMenuStrip = $menuStrip

$toolStrip = New-Object System.Windows.Forms.ToolStrip
$toolStrip.Dock = "Top"
$toolStrip.GripStyle = "Hidden"
$toolStrip.BackColor = [System.Drawing.SystemColors]::Control
$toolStrip.Padding = New-Object System.Windows.Forms.Padding(6, 3, 6, 3)

$btnImportData = New-Object System.Windows.Forms.ToolStripButton("Import Excel/CSV")
$btnScanAD     = New-Object System.Windows.Forms.ToolStripButton("Scan Live AD / Local")
$btnRefresh    = New-Object System.Windows.Forms.ToolStripButton("Refresh")
$btnProps      = New-Object System.Windows.Forms.ToolStripButton("Properties")
$btnFixSel     = New-Object System.Windows.Forms.ToolStripButton("Apply Solution")
$btnFixAll     = New-Object System.Windows.Forms.ToolStripButton("Remediate All")
$btnReset      = New-Object System.Windows.Forms.ToolStripButton("Reset Sandbox")
$lblModeBadge  = New-Object System.Windows.Forms.ToolStripLabel("Source: $script:DataSource (RSAT AD: $script:HasADModule)")
$lblModeBadge.ForeColor = [System.Drawing.Color]::DarkBlue

[void]$toolStrip.Items.AddRange(@(
    $btnImportData,
    $btnScanAD,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $btnRefresh,
    $btnProps,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $btnFixSel,
    $btnFixAll,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $btnReset,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $lblModeBadge
))

$statusStrip = New-Object System.Windows.Forms.StatusStrip
$statusStrip.Dock = "Bottom"
$statusStrip.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
$statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel("Ready")
[void]$statusStrip.Items.Add($statusLabel)

$workspacePanel = New-Object System.Windows.Forms.Panel
$workspacePanel.Dock = "Fill"
$workspacePanel.Padding = New-Object System.Windows.Forms.Padding(6, 4, 6, 4)

$form.Controls.Add($workspacePanel)
$form.Controls.Add($toolStrip)
$form.Controls.Add($menuStrip)
$form.Controls.Add($statusStrip)

$mainSplit = New-Object System.Windows.Forms.SplitContainer
$mainSplit.Dock = "Fill"
$mainSplit.SplitterWidth = 5
$mainSplit.SplitterDistance = 285
$mainSplit.BorderStyle = "Fixed3D"
$workspacePanel.Controls.Add($mainSplit)

$lblTreeHeader = New-Object System.Windows.Forms.Label
$lblTreeHeader.Text = "  Active Directory Users and Computers"
$lblTreeHeader.Dock = "Top"
$lblTreeHeader.Height = 26
$lblTreeHeader.TextAlign = "MiddleLeft"
$lblTreeHeader.BackColor = [System.Drawing.SystemColors]::ControlDark
$lblTreeHeader.ForeColor = [System.Drawing.Color]::White
$lblTreeHeader.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)

$treeView = New-Object System.Windows.Forms.TreeView
$treeView.Dock = "Fill"
$treeView.HideSelection = $false
$treeView.ShowLines = $true
$treeView.ShowPlusMinus = $true
$treeView.ShowRootLines = $true
$treeView.ItemHeight = 21
$treeView.Indent = 18
$treeView.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

$mainSplit.Panel1.Controls.Add($treeView)
$mainSplit.Panel1.Controls.Add($lblTreeHeader)

$rightSplit = New-Object System.Windows.Forms.SplitContainer
$rightSplit.Dock = "Fill"
$rightSplit.Orientation = "Horizontal"
$rightSplit.SplitterWidth = 5
$rightSplit.SplitterDistance = 420
$rightSplit.BorderStyle = "Fixed3D"
$mainSplit.Panel2.Controls.Add($rightSplit)

$lblContainerBanner = New-Object System.Windows.Forms.Label
$lblContainerBanner.Dock = "Top"
$lblContainerBanner.Height = 28
$lblContainerBanner.TextAlign = "MiddleLeft"
$lblContainerBanner.Font = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold)
$lblContainerBanner.BackColor = [System.Drawing.SystemColors]::InactiveCaption

$listView = New-Object System.Windows.Forms.ListView
$listView.Dock = "Fill"
$listView.View = "Details"
$listView.FullRowSelect = $true
$listView.GridLines = $true
$listView.MultiSelect = $false
$listView.Font = New-Object System.Drawing.Font("Segoe UI", 9)

[void]$listView.Columns.Add("Name", 165)
[void]$listView.Columns.Add("Type / Role", 185)
[void]$listView.Columns.Add("Department OU", 130)
[void]$listView.Columns.Add("Status", 80)
[void]$listView.Columns.Add("PriVis Risk", 85)
[void]$listView.Columns.Add("Group Memberships & Policy Findings", 430)

$rightSplit.Panel1.Controls.Add($listView)
$rightSplit.Panel1.Controls.Add($lblContainerBanner)

$rightSplit.Panel2.Padding = New-Object System.Windows.Forms.Padding(4)

$grpContainerSummary = New-Object System.Windows.Forms.GroupBox
$grpContainerSummary.Text = "Container Summary"
$grpContainerSummary.Dock = "Fill"
$grpContainerSummary.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$grpContainerSummary.Padding = New-Object System.Windows.Forms.Padding(8, 6, 8, 8)
$rightSplit.Panel2.Controls.Add($grpContainerSummary)

$summarySplit = New-Object System.Windows.Forms.SplitContainer
$summarySplit.Dock = "Fill"
$summarySplit.SplitterWidth = 6
$summarySplit.SplitterDistance = 310
$grpContainerSummary.Controls.Add($summarySplit)

$txtContainerStats = New-Object System.Windows.Forms.RichTextBox
$txtContainerStats.Dock = "Fill"
$txtContainerStats.ReadOnly = $true
$txtContainerStats.BackColor = [System.Drawing.SystemColors]::Window
$txtContainerStats.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$txtContainerStats.BorderStyle = "FixedSingle"
$txtContainerStats.Margin = New-Object System.Windows.Forms.Padding(4)
$summarySplit.Panel1.Controls.Add($txtContainerStats)

$grpSolutions = New-Object System.Windows.Forms.GroupBox
$grpSolutions.Text = "Solutions (At-Risk Remediation Playbook)"
$grpSolutions.Dock = "Fill"
$grpSolutions.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$grpSolutions.ForeColor = [System.Drawing.Color]::DarkRed
$grpSolutions.Padding = New-Object System.Windows.Forms.Padding(8, 6, 8, 6)
$summarySplit.Panel2.Controls.Add($grpSolutions)

$lvSolutions = New-Object System.Windows.Forms.ListView
$lvSolutions.Dock = "Fill"
$lvSolutions.View = "Details"
$lvSolutions.FullRowSelect = $true
$lvSolutions.GridLines = $true
$lvSolutions.Font = New-Object System.Drawing.Font("Segoe UI", 8.5)
$lvSolutions.ForeColor = [System.Drawing.Color]::Black

[void]$lvSolutions.Columns.Add("Severity", 75)
[void]$lvSolutions.Columns.Add("At-Risk Account", 150)
[void]$lvSolutions.Columns.Add("Department", 115)
[void]$lvSolutions.Columns.Add("Recommended Solution", 410)

$pnlSolActions = New-Object System.Windows.Forms.Panel
$pnlSolActions.Dock = "Bottom"
$pnlSolActions.Height = 36
$pnlSolActions.Padding = New-Object System.Windows.Forms.Padding(0, 6, 0, 0)

$btnApplySelectedSolution = New-Object System.Windows.Forms.Button
$btnApplySelectedSolution.Text = "Execute Highlighted Solution"
$btnApplySelectedSolution.Width = 200
$btnApplySelectedSolution.Height = 26
$btnApplySelectedSolution.Location = New-Object System.Drawing.Point(0, 6)
$btnApplySelectedSolution.Font = New-Object System.Drawing.Font("Segoe UI", 8.5, [System.Drawing.FontStyle]::Bold)
$btnApplySelectedSolution.ForeColor = [System.Drawing.Color]::Black

$btnApplyAllSolutions = New-Object System.Windows.Forms.Button
$btnApplyAllSolutions.Text = "Execute All At-Risk Solutions"
$btnApplyAllSolutions.Width = 200
$btnApplyAllSolutions.Height = 26
$btnApplyAllSolutions.Location = New-Object System.Drawing.Point(208, 6)
$btnApplyAllSolutions.Font = New-Object System.Drawing.Font("Segoe UI", 8.5)
$btnApplyAllSolutions.ForeColor = [System.Drawing.Color]::Black

[void]$pnlSolActions.Controls.AddRange(@($btnApplySelectedSolution, $btnApplyAllSolutions))
[void]$grpSolutions.Controls.Add($lvSolutions)
[void]$grpSolutions.Controls.Add($pnlSolActions)

$form.Add_Shown({
    $mainSplit.SplitterDistance = 285
    $rightSplit.SplitterDistance = [int]($workspacePanel.Height * 0.60)
    $summarySplit.SplitterDistance = 310
})

# ==============================================================================
# 6. DYNAMIC TREEVIEW & CONSOLE VIEW REFRESH
# ==============================================================================
function Build-ADTree {
    $form.Text = "Active Directory Users and Computers - [$script:DomainFQDN] (PriVis Universal Governance Edition)"
    $lblModeBadge.Text = "Source: $script:DataSource"
    $lblModeBadge.ForeColor = if ($script:LiveADMode) { [System.Drawing.Color]::DarkGreen } else { [System.Drawing.Color]::DarkBlue }

    $treeView.Nodes.Clear()
    $rootNode = New-Object System.Windows.Forms.TreeNode("Active Directory Users and Computers [$script:DomainFQDN]")
    $rootNode.Tag = "ROOT_DOMAIN"

    $domainNode = New-Object System.Windows.Forms.TreeNode($script:DomainFQDN)
    $domainNode.Tag = "ROOT_DOMAIN"

    $companyNode = New-Object System.Windows.Forms.TreeNode("$script:RootOUName (All Containers)")
    $companyNode.Tag = "ALL_COMPANY"
    $companyNode.NodeFont = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold)

    $deptList = @($script:Users | ForEach-Object { $_.dept } | Where-Object { $_ } | Select-Object -Unique)
    foreach ($ouName in $deptList) {
        $ouNode = New-Object System.Windows.Forms.TreeNode("OU=$ouName")
        $ouNode.Tag = $ouName
        if ($script:DeptColors.ContainsKey($ouName)) { $ouNode.BackColor = $script:DeptColors[$ouName] }
        [void]$companyNode.Nodes.Add($ouNode)
    }

    if ($script:Groups.Count -gt 0) {
        $sgNode = New-Object System.Windows.Forms.TreeNode("OU=Security Groups")
        $sgNode.Tag = "Security Groups"
        $sgNode.BackColor = $script:DeptColors["Security Groups"]
        [void]$companyNode.Nodes.Add($sgNode)
    }

    [void]$domainNode.Nodes.Add($companyNode)
    [void]$rootNode.Nodes.Add($domainNode)
    [void]$treeView.Nodes.Add($rootNode)

    $rootNode.ExpandAll()
    $treeView.SelectedNode = $companyNode
}

function Refresh-ConsoleView {
    $selectedTag = if ($treeView.SelectedNode) { $treeView.SelectedNode.Tag } else { "ALL_COMPANY" }
    $listView.Items.Clear()
    $lvSolutions.Items.Clear()

    $dcParts = ($script:DomainFQDN.Split('.') | ForEach-Object { "DC=$_" }) -join ","
    if ($script:DeptColors.ContainsKey($selectedTag)) {
        $lblContainerBanner.BackColor = $script:DeptColors[$selectedTag]
        $lblContainerBanner.Text = "  Container: OU=$selectedTag,OU=$script:RootOUName,$dcParts"
    } else {
        $lblContainerBanner.BackColor = [System.Drawing.SystemColors]::InactiveCaption
        $lblContainerBanner.Text = "  Container: OU=$script:RootOUName,$dcParts (All Departmental OUs)"
    }

    $scopedUsers = @()
    if ($selectedTag -eq "Security Groups") {
        foreach ($g in $script:Groups) {
            $members = @($script:Memberships | Where-Object { $_.group_id -eq $g.group_id } | ForEach-Object {
                $uid = $_.user_id
                ($script:Users | Where-Object { $_.user_id -eq $uid }).sam
            })
            $lvi = New-Object System.Windows.Forms.ListViewItem("$($g.group_name) ($($g.group_id))")
            [void]$lvi.SubItems.Add("Global Security Group")
            [void]$lvi.SubItems.Add("Security Groups")
            [void]$lvi.SubItems.Add("Risk: $($g.risk_level)")
            [void]$lvi.SubItems.Add($g.risk_level)
            [void]$lvi.SubItems.Add("Members ($($members.Count)): $($members -join ', ') | $($g.resource_scope)")
            $lvi.BackColor = $script:DeptColors["Security Groups"]
            $lvi.Tag = $g
            [void]$listView.Items.Add($lvi)
        }
    }
    else {
        $scopedUsers = if ($selectedTag -in @("ROOT_DOMAIN", "ALL_COMPANY")) {
            $script:Users
        } else {
            @($script:Users | Where-Object { $_.dept -eq $selectedTag })
        }

        foreach ($u in $scopedUsers) {
            $risk = Get-UserRiskAnalysis -User $u
            $uGroups = @($script:Memberships | Where-Object { $_.user_id -eq $u.user_id } | ForEach-Object {
                $gid = $_.group_id
                ($script:Groups | Where-Object { $_.group_id -eq $gid }).group_name
            })
            $statusTxt = if ($u.enabled) { "Enabled" } else { "Disabled" }
            $detailTxt = if ($risk.Findings) { "Groups: [$($uGroups -join ', ')] - $($risk.Findings)" } else { "Groups: [$($uGroups -join ', ')] - Policy Compliant" }

            $lvi = New-Object System.Windows.Forms.ListViewItem("$($u.name) ($($u.sam))")
            [void]$lvi.SubItems.Add("$($u.role) [$($u.worker_type)]")
            [void]$lvi.SubItems.Add($u.dept)
            [void]$lvi.SubItems.Add($statusTxt)
            [void]$lvi.SubItems.Add($risk.Severity)
            [void]$lvi.SubItems.Add($detailTxt)

            if ($script:DeptColors.ContainsKey($u.dept)) { $lvi.BackColor = $script:DeptColors[$u.dept] }
            if ($risk.Severity -eq "Critical") { $lvi.ForeColor = [System.Drawing.Color]::FromArgb(185, 28, 28); $lvi.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold) }
            elseif ($risk.Severity -eq "High") { $lvi.ForeColor = [System.Drawing.Color]::FromArgb(190, 24, 93); $lvi.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold) }
            elseif ($risk.Severity -eq "Medium") { $lvi.ForeColor = [System.Drawing.Color]::FromArgb(194, 65, 12); $lvi.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold) }
            elseif ($risk.Severity -eq "Low") { $lvi.ForeColor = [System.Drawing.Color]::FromArgb(161, 98, 7) }
            elseif (-not $u.enabled) { $lvi.ForeColor = [System.Drawing.Color]::DimGray }

            $lvi.Tag = $u
            [void]$listView.Items.Add($lvi)
        }
    }

    # Container Summary & Dynamic Color Legend
    $allTargetUsers = if ($selectedTag -in @("ROOT_DOMAIN", "ALL_COMPANY", "Security Groups")) { $script:Users } else { $scopedUsers }
    $totalCount     = $allTargetUsers.Count
    $enabledCount   = @($allTargetUsers | Where-Object { $_.enabled }).Count
    $atRiskList     = @()
    foreach ($u in $allTargetUsers) {
        $r = Get-UserRiskAnalysis -User $u
        if ($r.Severity -ne "Compliant") {
            $atRiskList += [PSCustomObject]@{ User = $u; Risk = $r }
        }
    }
    $atRiskList = $atRiskList | Sort-Object { $_.Risk.SevRank } -Descending

    $txtContainerStats.Clear()
    $txtContainerStats.SelectionFont = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold)
    $txtContainerStats.AppendText("Selected OU: $selectedTag`r`n")
    $txtContainerStats.SelectionFont = New-Object System.Drawing.Font("Segoe UI", 9)
    $txtContainerStats.AppendText("Total User Objects: $totalCount  |  Enabled: $enabledCount  |  At-Risk: $($atRiskList.Count)`r`n")
    $txtContainerStats.AppendText("--------------------------------------------------`r`n")
    $txtContainerStats.SelectionFont = New-Object System.Drawing.Font("Segoe UI", 8.5, [System.Drawing.FontStyle]::Bold)
    $txtContainerStats.AppendText("Department Color Legend:`r`n")
    $txtContainerStats.SelectionFont = New-Object System.Drawing.Font("Segoe UI", 8.5)
    foreach ($k in $script:DeptColorLabels.Keys) {
        $txtContainerStats.AppendText("  * ${k}: $($script:DeptColorLabels[$k])`r`n")
    }
    $txtContainerStats.SelectionFont = New-Object System.Drawing.Font("Segoe UI", 8.5, [System.Drawing.FontStyle]::Bold)
    $txtContainerStats.AppendText("Alert Color Legend:`r`n")
    $txtContainerStats.SelectionFont = New-Object System.Drawing.Font("Segoe UI", 8.5)
    $txtContainerStats.AppendText("  * Critical: Red | High: Pink | Medium: Orange | Low: Yellow`r`n")

    # Populate Solutions Box
    if ($atRiskList.Count -eq 0) {
        $sItem = New-Object System.Windows.Forms.ListViewItem("OK")
        [void]$sItem.SubItems.Add("All Accounts Compliant")
        [void]$sItem.SubItems.Add($selectedTag)
        [void]$sItem.SubItems.Add("Zero least-privilege violations detected in this container.")
        $sItem.BackColor = [System.Drawing.Color]::FromArgb(220, 252, 231)
        [void]$lvSolutions.Items.Add($sItem)
        $btnApplySelectedSolution.Enabled = $false
        $btnApplyAllSolutions.Enabled = $false
    }
    else {
        $btnApplySelectedSolution.Enabled = $true
        $btnApplyAllSolutions.Enabled = $true
        foreach ($entry in $atRiskList) {
            $u = $entry.User
            $r = $entry.Risk
            $sItem = New-Object System.Windows.Forms.ListViewItem($r.Severity.ToUpper())
            [void]$sItem.SubItems.Add("$($u.name) ($($u.sam))")
            [void]$sItem.SubItems.Add($u.dept)
            [void]$sItem.SubItems.Add($r.Solution)
            $sItem.Tag = $u.user_id

            if ($r.Severity -eq "Critical") { $sItem.BackColor = [System.Drawing.Color]::FromArgb(254, 202, 202); $sItem.ForeColor = [System.Drawing.Color]::FromArgb(127, 29, 29) } # Red
            elseif ($r.Severity -eq "High") { $sItem.BackColor = [System.Drawing.Color]::FromArgb(252, 231, 243); $sItem.ForeColor = [System.Drawing.Color]::FromArgb(131, 24, 67) } # Pink
            elseif ($r.Severity -eq "Medium") { $sItem.BackColor = [System.Drawing.Color]::FromArgb(255, 237, 213); $sItem.ForeColor = [System.Drawing.Color]::FromArgb(124, 45, 18) } # Orange
            else { $sItem.BackColor = [System.Drawing.Color]::FromArgb(254, 249, 195); $sItem.ForeColor = [System.Drawing.Color]::FromArgb(113, 63, 18) } # Yellow

            [void]$lvSolutions.Items.Add($sItem)
        }
        $lvSolutions.Items[0].Selected = $true
    }

    $auditStr = $script:AuditDate.ToString("yyyy-MM-dd")
    $statusLabel.Text = "Source: $script:DataSource | Container: $selectedTag | Objects: $($listView.Items.Count) | At-Risk: $($atRiskList.Count) | Audit Date: $auditStr"
}

# ==============================================================================
# 7. USER PROPERTIES DIALOG
# ==============================================================================
function Show-UserPropertiesDialog {
    param($User)
    if (-not $User -or -not $User.user_id) { return }
    $risk = Get-UserRiskAnalysis -User $User

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($User.name) Properties"
    $dlg.Size = New-Object System.Drawing.Size(470, 440)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false

    $tabs = New-Object System.Windows.Forms.TabControl
    $tabs.Location = New-Object System.Drawing.Point(10, 10)
    $tabs.Size = New-Object System.Drawing.Size(434, 345)

    $tabGen = New-Object System.Windows.Forms.TabPage("General & Account")
    if ($script:DeptColors.ContainsKey($User.dept)) { $tabGen.BackColor = $script:DeptColors[$User.dept] }
    $lblGen = New-Object System.Windows.Forms.Label
    $lblGen.Location = New-Object System.Drawing.Point(14, 14)
    $lblGen.Size = New-Object System.Drawing.Size(395, 285)
    $lblGen.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
    $lblGen.Text = @"
Display Name:       $($User.name)
User ID:            $($User.user_id)
Logon Name:         $($User.sam)@$script:DomainFQDN
Department OU:      OU=$($User.dept),OU=$script:RootOUName
Job Role:           $($User.role)
Worker Type:        $($User.worker_type)
Account Status:     $(if ($User.enabled) { 'Enabled (Active)' } else { 'Disabled' })
Contract End Date:  $(if ($User.end_date) { $User.end_date } else { 'Never (Permanent)' })
"@
    [void]$tabGen.Controls.Add($lblGen)

    $tabMem = New-Object System.Windows.Forms.TabPage("Member Of")
    $lbGroups = New-Object System.Windows.Forms.ListBox
    $lbGroups.Location = New-Object System.Drawing.Point(12, 14)
    $lbGroups.Size = New-Object System.Drawing.Size(400, 210)
    foreach ($m in ($script:Memberships | Where-Object { $_.user_id -eq $User.user_id })) {
        $g = $script:Groups | Where-Object { $_.group_id -eq $m.group_id }
        if ($g) { [void]$lbGroups.Items.Add("$($g.group_id) - $($g.group_name) [Risk: $($g.risk_level)]") }
    }

    $cmbAddGroup = New-Object System.Windows.Forms.ComboBox
    $cmbAddGroup.Location = New-Object System.Drawing.Point(12, 236)
    $cmbAddGroup.Size = New-Object System.Drawing.Size(220, 24)
    $cmbAddGroup.DropDownStyle = "DropDownList"
    foreach ($g in $script:Groups) { [void]$cmbAddGroup.Items.Add("$($g.group_id) - $($g.group_name)") }
    if ($cmbAddGroup.Items.Count -gt 0) { $cmbAddGroup.SelectedIndex = 0 }

    $btnAddGrp = New-Object System.Windows.Forms.Button
    $btnAddGrp.Text = "Add Group"
    $btnAddGrp.Location = New-Object System.Drawing.Point(240, 235)
    $btnAddGrp.Size = New-Object System.Drawing.Size(80, 25)
    $btnAddGrp.Add_Click({
        if (-not $cmbAddGroup.SelectedItem) { return }
        $selGid = $cmbAddGroup.SelectedItem.ToString().Split(" ")[0]
        $exists = $script:Memberships | Where-Object { $_.user_id -eq $User.user_id -and $_.group_id -eq $selGid }
        if (-not $exists) {
            [void]$script:Memberships.Add([PSCustomObject]@{
                user_id = $User.user_id; group_id = $selGid; approval_status = "Missing"; approval_ticket = $null; approval_expires = $null
            })
            $gObj = $script:Groups | Where-Object { $_.group_id -eq $selGid }
            if ($script:LiveADMode -and $script:HasADModule -and $gObj) {
                Add-ADGroupMember -Identity $gObj.group_name -Members $User.sam -ErrorAction SilentlyContinue
            }
            [void]$lbGroups.Items.Add("$($gObj.group_id) - $($gObj.group_name) [Risk: $($gObj.risk_level)]")
            Refresh-ConsoleView
        }
    })

    $btnRemGrp = New-Object System.Windows.Forms.Button
    $btnRemGrp.Text = "Remove"
    $btnRemGrp.Location = New-Object System.Drawing.Point(326, 235)
    $btnRemGrp.Size = New-Object System.Drawing.Size(86, 25)
    $btnRemGrp.Add_Click({
        if ($lbGroups.SelectedItem) {
            $selGid = $lbGroups.SelectedItem.ToString().Split(" ")[0]
            $target = $script:Memberships | Where-Object { $_.user_id -eq $User.user_id -and $_.group_id -eq $selGid }
            $gObj   = $script:Groups | Where-Object { $_.group_id -eq $selGid }
            if ($script:LiveADMode -and $script:HasADModule -and $gObj) {
                Remove-ADGroupMember -Identity $gObj.group_name -Members $User.sam -Confirm:$false -ErrorAction SilentlyContinue
            }
            if ($target) { [void]$script:Memberships.Remove($target) }
            $lbGroups.Items.Remove($lbGroups.SelectedItem)
            Refresh-ConsoleView
        }
    })
    [void]$tabMem.Controls.AddRange(@($lbGroups, $cmbAddGroup, $btnAddGrp, $btnRemGrp))

    $tabPriv = New-Object System.Windows.Forms.TabPage("PriVis Solution")
    $txtPriv = New-Object System.Windows.Forms.TextBox
    $txtPriv.Multiline = $true
    $txtPriv.ReadOnly = $true
    $txtPriv.Location = New-Object System.Drawing.Point(12, 14)
    $txtPriv.Size = New-Object System.Drawing.Size(400, 240)
    $txtPriv.Text = "Risk Level: $($risk.Severity)`r`n`r`nFindings:`r`n$($risk.Findings)`r`n`r`nRecommended Solution:`r`n$($risk.Solution)"

    $btnDlgFix = New-Object System.Windows.Forms.Button
    $btnDlgFix.Text = "Apply PriVis Remediation Now"
    $btnDlgFix.Location = New-Object System.Drawing.Point(12, 265)
    $btnDlgFix.Size = New-Object System.Drawing.Size(210, 28)
    $btnDlgFix.Enabled = ($risk.Severity -ne "Compliant")
    $btnDlgFix.Add_Click({
        Invoke-UserRemediation -UserId $User.user_id
        Refresh-ConsoleView
        $dlg.Close()
    })
    [void]$tabPriv.Controls.AddRange(@($txtPriv, $btnDlgFix))

    [void]$tabs.TabPages.AddRange(@($tabGen, $tabMem, $tabPriv))
    [void]$dlg.Controls.Add($tabs)

    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = "OK"
    $btnOK.Location = New-Object System.Drawing.Point(369, 365)
    $btnOK.Add_Click({ $dlg.Close() })
    [void]$dlg.Controls.Add($btnOK)

    [void]$dlg.ShowDialog()
}

# ==============================================================================
# 8. WIRE EVENT HANDLERS (IMPORT, LIVE AD SCAN, REMEDIATION, EXPORT)
# ==============================================================================
$treeView.Add_AfterSelect({ Refresh-ConsoleView })
$btnRefresh.Add_Click({ Refresh-ConsoleView })
$miShowAll.Add_Click({ $treeView.SelectedNode = $treeView.Nodes[0].Nodes[0].Nodes[0] })

$importExcelHandler = {
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Title = "Select Organization Excel Workbook"
    $ofd.Filter = "Excel Workbooks (*.xlsx;*.xls)|*.xlsx;*.xls"
    if ($ofd.ShowDialog() -eq "OK") {
        try {
            $statusLabel.Text = "Importing Excel workbook..."
            [System.Windows.Forms.Application]::DoEvents()
            Import-FromExcelWorkbook -FilePath $ofd.FileName
            Build-ADTree
            Refresh-ConsoleView
            [System.Windows.Forms.MessageBox]::Show("Successfully loaded $($script:Users.Count) users and $($script:Groups.Count) groups from $([System.IO.Path]::GetFileName($ofd.FileName)).", "Excel Import Complete", "OK", "Information")
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Excel import failed:`n$($_.Exception.Message)`n`nTip: If Microsoft Excel is not installed on this VM, use 'Import Organization CSV Files (.csv)...' instead.", "Import Error", "OK", "Error")
        }
    }
}
$miImportExcel.Add_Click($importExcelHandler)

$importCsvHandler = {
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Title = "Select One or More Organization CSV Files (users.csv, groups.csv, memberships.csv, access_policy.csv)"
    $ofd.Filter = "CSV Files (*.csv)|*.csv"
    $ofd.Multiselect = $true
    if ($ofd.ShowDialog() -eq "OK") {
        try {
            Import-FromCsvFiles -CsvPaths $ofd.FileNames
            Build-ADTree
            Refresh-ConsoleView
            [System.Windows.Forms.MessageBox]::Show("Successfully imported $($script:Users.Count) users and $($script:Groups.Count) groups from CSV file(s).", "CSV Import Complete", "OK", "Information")
        } catch {
            [System.Windows.Forms.MessageBox]::Show("CSV import failed:`n$($_.Exception.Message)", "Import Error", "OK", "Error")
        }
    }
}
$miImportCsv.Add_Click($importCsvHandler)

$btnImportData.Add_Click({
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Title = "Import Organization Data (Excel Workbook or CSV Files)"
    $ofd.Filter = "Supported Data Files (*.xlsx;*.xls;*.csv)|*.xlsx;*.xls;*.csv|Excel Workbooks (*.xlsx;*.xls)|*.xlsx;*.xls|CSV Files (*.csv)|*.csv"
    $ofd.Multiselect = $true
    if ($ofd.ShowDialog() -eq "OK") {
        try {
            if ($ofd.FileNames[0] -match "\.xlsx?$") {
                Import-FromExcelWorkbook -FilePath $ofd.FileNames[0]
            } else {
                Import-FromCsvFiles -CsvPaths $ofd.FileNames
            }
            Build-ADTree
            Refresh-ConsoleView
            [System.Windows.Forms.MessageBox]::Show("Loaded $($script:Users.Count) users and $($script:Groups.Count) groups into PriVis Governance Console.", "Data Import Complete", "OK", "Information")
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Import failed:`n$($_.Exception.Message)", "Import Error", "OK", "Error")
        }
    }
})

$scanLiveADHandler = {
    try {
        $statusLabel.Text = "Scanning system directory (Active Directory / Local Windows Accounts)..."
        [System.Windows.Forms.Application]::DoEvents()
        Invoke-LiveADDomainScan
        Build-ADTree
        Refresh-ConsoleView
        $modeDesc = if ($script:LiveADMode) { "Active Directory Domain ($($script:DomainFQDN))" } else { "Local Windows Directory ($($env:COMPUTERNAME)) - No Domain Controller detected" }
        [System.Windows.Forms.MessageBox]::Show("Directory Scan Complete!`nSource: $modeDesc`nDiscovered $($script:Users.Count) user accounts and $($script:Groups.Count) security groups.", "Directory Scan Complete", "OK", "Information")
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Directory scan encountered an error:`n$($_.Exception.Message)", "Scan Error", "OK", "Error")
        Refresh-ConsoleView
    }
}
$miScanLiveAD.Add_Click($scanLiveADHandler)
$btnScanAD.Add_Click($scanLiveADHandler)

$miExportTpl.Add_Click({
    $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
    $fbd.Description = "Choose a folder to save sample CSV schema templates (users.csv, groups.csv, memberships.csv, access_policy.csv)"
    if ($fbd.ShowDialog() -eq "OK") {
        Export-SampleTemplateCsvs -FolderPath $fbd.SelectedPath
        [System.Windows.Forms.MessageBox]::Show("Saved 4 CSV schema files to:`n$($fbd.SelectedPath)`n`nYou can populate these templates with any company's directory data and import them via 'Import Excel/CSV'.", "Templates Exported", "OK", "Information")
    }
})

$listView.Add_DoubleClick({
    if ($listView.SelectedItems.Count -gt 0 -and $listView.SelectedItems[0].Tag.user_id) {
        Show-UserPropertiesDialog -User $listView.SelectedItems[0].Tag
    }
})

$btnProps.Add_Click({
    if ($listView.SelectedItems.Count -gt 0 -and $listView.SelectedItems[0].Tag.user_id) {
        Show-UserPropertiesDialog -User $listView.SelectedItems[0].Tag
    }
})

$applySelectedHandler = {
    if ($lvSolutions.SelectedItems.Count -gt 0 -and $lvSolutions.SelectedItems[0].Tag) {
        Invoke-UserRemediation -UserId $lvSolutions.SelectedItems[0].Tag
        Refresh-ConsoleView
    }
    elseif ($listView.SelectedItems.Count -gt 0 -and $listView.SelectedItems[0].Tag.user_id) {
        Invoke-UserRemediation -UserId $listView.SelectedItems[0].Tag.user_id
        Refresh-ConsoleView
    }
}
$btnApplySelectedSolution.Add_Click($applySelectedHandler)
$btnFixSel.Add_Click($applySelectedHandler)
$miRemediateSel.Add_Click($applySelectedHandler)

$applyAllHandler = {
    $fixedCount = 0
    foreach ($u in $script:Users) {
        $r = Get-UserRiskAnalysis -User $u
        if ($r.Severity -ne "Compliant") {
            Invoke-UserRemediation -UserId $u.user_id
            $fixedCount++
        }
    }
    Refresh-ConsoleView
    [System.Windows.Forms.MessageBox]::Show("Remediated $fixedCount at-risk account(s) according to least-privilege policy.", "PriVis Remediation Complete", "OK", "Information")
}
$btnApplyAllSolutions.Add_Click($applyAllHandler)
$btnFixAll.Add_Click($applyAllHandler)
$miRemediateAll.Add_Click($applyAllHandler)

$resetHandler = {
    Reset-LabState
    Build-ADTree
    Refresh-ConsoleView
}
$btnReset.Add_Click($resetHandler)
$miResetLab.Add_Click($resetHandler)

$miExportPS.Add_Click({
    $sfd = New-Object System.Windows.Forms.SaveFileDialog
    $sfd.Filter = "PowerShell Script (*.ps1)|*.ps1"
    $sfd.FileName = "PriVis_AD_Remediation_Export.ps1"
    if ($sfd.ShowDialog() -eq "OK") {
        $lines = @("# Generated by PriVis Universal ADUC Console on $(Get-Date -Format 'yyyy-MM-dd HH:mm')", "# Source: $script:DataSource", "Import-Module ActiveDirectory")
        foreach ($u in $script:Users) {
            if (-not $u.enabled) { $lines += "Disable-ADAccount -Identity '$($u.sam)'" }
            $activeGrps = @($script:Memberships | Where-Object { $_.user_id -eq $u.user_id } | ForEach-Object {
                $gid = $_.group_id
                ($script:Groups | Where-Object { $_.group_id -eq $gid }).group_name
            })
            $lines += "# $($u.name) ($($u.dept) - $($u.role)): Active Groups = $($activeGrps -join ', ')"
        }
        $lines -join "`r`n" | Out-File -FilePath $sfd.FileName -Encoding UTF8
        [System.Windows.Forms.MessageBox]::Show("Exported PowerShell commands to $($sfd.FileName)", "Export Complete", "OK", "Information")
    }
})

$miAbout.Add_Click({
    [System.Windows.Forms.MessageBox]::Show("PriVis Universal Active Directory Users and Computers (MMC Edition)`nSupports: Built-In Sandbox, Excel/CSV Organization Imports, and Live Active Directory / Local Windows Scanning.", "About PriVis", "OK", "Information")
})

$miExit.Add_Click({ $form.Close() })

Build-ADTree
[void]$form.ShowDialog()
