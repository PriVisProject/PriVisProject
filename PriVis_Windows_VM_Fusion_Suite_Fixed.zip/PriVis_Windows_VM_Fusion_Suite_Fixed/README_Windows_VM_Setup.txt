========================================================================
PriVis Active Directory Users & Computers (MMC Edition) - Windows VM Suite
========================================================================
Target Environment: Windows 10 / Windows 11 / Windows Server (VMware Fusion)
Domain:             eaglebusiness.local

HOW TO RUN IN YOUR WINDOWS VM (NO INSTALLATION REQUIRED):
1. Extract this ZIP folder anywhere in your Windows VM (e.g., Desktop).
2. Double-click 'Launch_PriVis_ADUC.bat' (or right-click 'PriVis_ADUC_Console.ps1' -> Run with PowerShell).
3. The native Windows Desktop MMC application will open immediately.
