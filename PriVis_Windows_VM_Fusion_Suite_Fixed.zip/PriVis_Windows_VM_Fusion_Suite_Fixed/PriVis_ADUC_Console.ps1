﻿<#
.SYNOPSIS
    PriVis ADUC MMC Console - Native Windows Desktop Application for VMware Fusion Lab Testing
.DESCRIPTION
    Self-contained Windows Forms (.NET Framework) MMC-style Active Directory Users and Computers
    console with PriVis Least-Privilege Governance, Container Summary & Solutions box,
    department color-coding, interactive Properties dialogs, and Live AD / Simulation toggle.
    Runs natively on any Windows 10, Windows 11, or Windows Server VM without installing dependencies.
#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# ==============================================================================
# 1. EMBEDDED DATASET (Eagle Business Solutions - Audit Date: 2026-11-14)
# ==============================================================================
$AuditDate = [datetime]"2026-11-14"

$DeptColors = @{
    "Customer Support" = [System.Drawing.Color]::FromArgb(204, 251, 241) # Teal tint
    "IT"               = [System.Drawing.Color]::FromArgb(219, 234, 254) # Royal Blue tint
    "Sales"            = [System.Drawing.Color]::FromArgb(254, 243, 199) # Amber tint
    "Finance"          = [System.Drawing.Color]::FromArgb(209, 250, 229) # Emerald tint
    "HR"               = [System.Drawing.Color]::FromArgb(237, 233, 254) # Purple tint
    "Security Groups"  = [System.Drawing.Color]::FromArgb(241, 245, 249) # Slate tint
}

$DeptBadgeColors = @{
    "Customer Support" = [System.Drawing.Color]::FromArgb(13, 148, 136)
    "IT"               = [System.Drawing.Color]::FromArgb(29, 78, 216)
    "Sales"            = [System.Drawing.Color]::FromArgb(180, 83, 9)
    "Finance"          = [System.Drawing.Color]::FromArgb(4, 120, 87)
    "HR"               = [System.Drawing.Color]::FromArgb(109, 40, 217)
    "Security Groups"  = [System.Drawing.Color]::FromArgb(71, 85, 105)
}

$RawUsersJson = @'
[
  {
    "user_id": "U001",
    "name": "Maya Torres",
    "sam": "mtorres",
    "dept": "Customer Support",
    "role": "Support Rep",
    "worker_type": "Part-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U002",
    "name": "Alex Chen",
    "sam": "achen",
    "dept": "IT",
    "role": "IT Admin",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U003",
    "name": "Taylor Morgan",
    "sam": "tmorgan",
    "dept": "IT",
    "role": "IT Contractor",
    "worker_type": "Contractor",
    "enabled": true,
    "end_date": "2026-11-01"
  },
  {
    "user_id": "U004",
    "name": "Jordan Lee",
    "sam": "jlee",
    "dept": "Customer Support",
    "role": "Support Rep",
    "worker_type": "Part-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U005",
    "name": "Sam Patel",
    "sam": "spatel",
    "dept": "Sales",
    "role": "Sales Rep",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U006",
    "name": "Chris Rivera",
    "sam": "crivera",
    "dept": "Finance",
    "role": "Finance Analyst",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U007",
    "name": "Renee Brooks",
    "sam": "rbrooks",
    "dept": "Finance",
    "role": "Payroll Specialist",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U008",
    "name": "Avery Kim",
    "sam": "akim",
    "dept": "Sales",
    "role": "Sales Manager",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U009",
    "name": "Morgan Ellis",
    "sam": "mellis",
    "dept": "HR",
    "role": "HR Coordinator",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U010",
    "name": "Jamie Price",
    "sam": "jprice",
    "dept": "IT",
    "role": "IT Support",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U011",
    "name": "Casey Nguyen",
    "sam": "cnguyen",
    "dept": "Finance",
    "role": "Finance Manager",
    "worker_type": "Full-Time",
    "enabled": true,
    "end_date": null
  },
  {
    "user_id": "U012",
    "name": "Devon Reed",
    "sam": "dreed",
    "dept": "Sales",
    "role": "Sales Rep",
    "worker_type": "Former Employee",
    "enabled": false,
    "end_date": "2026-09-30"
  }
]
'@

$RawGroupsJson = @'
[
  {
    "group_id": "G001",
    "group_name": "Customer-Support",
    "risk_level": "Low",
    "resource_scope": "CRM - customer records",
    "description": "Read and update routine customer support tickets"
  },
  {
    "group_id": "G002",
    "group_name": "Payroll-Editors",
    "risk_level": "High",
    "resource_scope": "Payroll application",
    "description": "Edit payroll records and payroll adjustments"
  },
  {
    "group_id": "G003",
    "group_name": "Server-Admins",
    "risk_level": "Critical",
    "resource_scope": "Server administration",
    "description": "Privileged access to managed company servers"
  },
  {
    "group_id": "G004",
    "group_name": "Sales-Reports",
    "risk_level": "Low",
    "resource_scope": "Sales reporting portal",
    "description": "Read and create standard sales reports"
  },
  {
    "group_id": "G005",
    "group_name": "Finance-Reports",
    "risk_level": "Medium",
    "resource_scope": "Financial reporting portal",
    "description": "Read internal financial reports"
  },
  {
    "group_id": "G006",
    "group_name": "HR-Records",
    "risk_level": "High",
    "resource_scope": "HR records application",
    "description": "View and update confidential employee records"
  },
  {
    "group_id": "G007",
    "group_name": "Helpdesk-Reset",
    "risk_level": "High",
    "resource_scope": "IT service desk",
    "description": "Reset company account credentials within approved scope"
  },
  {
    "group_id": "G008",
    "group_name": "All-Employees",
    "risk_level": "Low",
    "resource_scope": "Company intranet",
    "description": "Read internal general company resources"
  }
]
'@

$RawMembJson = @'
[
  {
    "user_id": "U001",
    "group_id": "G001",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U001",
    "group_id": "G002",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U001",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U002",
    "group_id": "G003",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U002",
    "group_id": "G007",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U002",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U003",
    "group_id": "G003",
    "approval_status": "Missing",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U003",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U004",
    "group_id": "G001",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U004",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U005",
    "group_id": "G004",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U005",
    "group_id": "G005",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U005",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U006",
    "group_id": "G005",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U006",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U007",
    "group_id": "G002",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U007",
    "group_id": "G005",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U007",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U008",
    "group_id": "G004",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U008",
    "group_id": "G005",
    "approval_status": "Approved",
    "approval_ticket": "APR-2026-014",
    "approval_expires": "2026-12-15"
  },
  {
    "user_id": "U008",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U009",
    "group_id": "G006",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U009",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U010",
    "group_id": "G007",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U010",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U011",
    "group_id": "G002",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U011",
    "group_id": "G005",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U011",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U012",
    "group_id": "G004",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  },
  {
    "user_id": "U012",
    "group_id": "G008",
    "approval_status": "Not Required",
    "approval_ticket": null,
    "approval_expires": null
  }
]
'@

$RawPolicyJson = @'
[
  {
    "role": "Support Rep",
    "group_id": "G001",
    "access_decision": "Allowed",
    "policy_reason": "Support team requires customer ticket access"
  },
  {
    "role": "Support Rep",
    "group_id": "G002",
    "access_decision": "Denied",
    "policy_reason": "Support role must not edit payroll"
  },
  {
    "role": "Support Rep",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet for all current workers"
  },
  {
    "role": "IT Admin",
    "group_id": "G003",
    "access_decision": "Allowed",
    "policy_reason": "IT administrator has approved server administration duties"
  },
  {
    "role": "IT Admin",
    "group_id": "G007",
    "access_decision": "Allowed",
    "policy_reason": "IT administrator can manage service desk credential resets"
  },
  {
    "role": "IT Admin",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "IT Contractor",
    "group_id": "G003",
    "access_decision": "Approval Required",
    "policy_reason": "Privileged server access requires a time-limited exception"
  },
  {
    "role": "IT Contractor",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet available during active contract"
  },
  {
    "role": "Sales Rep",
    "group_id": "G004",
    "access_decision": "Allowed",
    "policy_reason": "Sales representatives require sales reporting"
  },
  {
    "role": "Sales Rep",
    "group_id": "G005",
    "access_decision": "Denied",
    "policy_reason": "Sales representatives should not access financial reporting"
  },
  {
    "role": "Sales Rep",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "Finance Analyst",
    "group_id": "G005",
    "access_decision": "Allowed",
    "policy_reason": "Finance analysts require financial reports"
  },
  {
    "role": "Finance Analyst",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "Payroll Specialist",
    "group_id": "G002",
    "access_decision": "Allowed",
    "policy_reason": "Payroll specialists maintain payroll data"
  },
  {
    "role": "Payroll Specialist",
    "group_id": "G005",
    "access_decision": "Allowed",
    "policy_reason": "Payroll specialists can view financial reports"
  },
  {
    "role": "Payroll Specialist",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "Sales Manager",
    "group_id": "G004",
    "access_decision": "Allowed",
    "policy_reason": "Sales managers require sales reporting"
  },
  {
    "role": "Sales Manager",
    "group_id": "G005",
    "access_decision": "Approval Required",
    "policy_reason": "Finance reporting for Sales managers requires documented approval"
  },
  {
    "role": "Sales Manager",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "HR Coordinator",
    "group_id": "G006",
    "access_decision": "Allowed",
    "policy_reason": "HR coordinators manage employee records"
  },
  {
    "role": "HR Coordinator",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "IT Support",
    "group_id": "G007",
    "access_decision": "Allowed",
    "policy_reason": "IT support staff perform credential resets"
  },
  {
    "role": "IT Support",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  },
  {
    "role": "Finance Manager",
    "group_id": "G002",
    "access_decision": "Allowed",
    "policy_reason": "Finance managers may manage payroll operations"
  },
  {
    "role": "Finance Manager",
    "group_id": "G005",
    "access_decision": "Allowed",
    "policy_reason": "Finance managers require financial reports"
  },
  {
    "role": "Finance Manager",
    "group_id": "G008",
    "access_decision": "Allowed",
    "policy_reason": "General intranet access"
  }
]
'@

function Reset-LabState {
    $script:Users       = ($RawUsersJson | ConvertFrom-Json)
    $script:Groups      = ($RawGroupsJson | ConvertFrom-Json)
    $script:Memberships = [System.Collections.ArrayList]@($RawMembJson | ConvertFrom-Json)
    $script:Policies    = ($RawPolicyJson | ConvertFrom-Json)
    $script:LiveADMode  = $false
}
Reset-LabState

# Check if RSAT ActiveDirectory module is installed in this Windows VM
$script:HasADModule = $null -ne (Get-Module -ListAvailable -Name ActiveDirectory)

# ==============================================================================
# 2. PRIVIS RISK & SOLUTION ENGINE
# ==============================================================================
function Get-UserRiskAnalysis {
    param($User)
    $uMembs = @($script:Memberships | Where-Object { $_.user_id -eq $User.user_id })
    $findings = @()
    $severity = "Compliant"
    $sevRank = 0

    $isExpired = $false
    if ($User.end_date) {
        $ed = [datetime]$User.end_date
        if ($ed -lt $AuditDate) { $isExpired = $true }
    }

    if ($User.worker_type -eq "Contractor" -and $isExpired -and $User.enabled) {
        $findings += "CRITICAL: Contractor end date ($($User.end_date)) passed, account still ENABLED."
        if ($sevRank -lt 4) { $sevRank = 4; $severity = "Critical" }
    }

    if (-not $User.enabled -and $uMembs.Count -gt 0) {
        $gNames = ($uMembs | ForEach-Object {
            $gid = $_.group_id
            ($script:Groups | Where-Object { $_.group_id -eq $gid }).group_name
        }) -join ", "
        $findings += "LOW: Disabled former employee retains residual groups ($gNames)."
        if ($sevRank -lt 1) { $sevRank = 1; $severity = "Low" }
    }

    foreach ($m in $uMembs) {
        $grp = $script:Groups | Where-Object { $_.group_id -eq $m.group_id }
        $pol = $script:Policies | Where-Object { $_.role -eq $User.role -and $_.group_id -eq $m.group_id }
        if ($pol) {
            if ($pol.access_decision -eq "Denied") {
                $r = if ($grp.risk_level -eq "High" -or $grp.risk_level -eq "Critical") { 3 } else { 2 }
                $lbl = if ($r -eq 3) { "HIGH" } else { "MEDIUM" }
                $findings += "${lbl}: Explicitly denied group $($grp.group_name) ($($pol.policy_reason))."
                if ($sevRank -lt $r) { $sevRank = $r; $severity = if ($r -eq 3) { "High" } else { "Medium" } }
            }
            elseif ($pol.access_decision -eq "Approval Required") {
                $validExp = $false
                if ($m.approval_status -eq "Approved" -and $m.approval_expires) {
                    if ([datetime]$m.approval_expires -ge $AuditDate) { $validExp = $true }
                }
                if (-not $validExp) {
                    $r = if ($grp.risk_level -eq "Critical") { 4 } else { 3 }
                    $lbl = if ($r -eq 4) { "CRITICAL" } else { "HIGH" }
                    $findings += "${lbl}: $($grp.group_name) requires valid approval (Status: $($m.approval_status))."
                    if ($sevRank -lt $r) { $sevRank = $r; $severity = if ($r -eq 4) { "Critical" } else { "High" } }
                }
            }
        }
    }

    # Generate actionable solution text
    $solution = "No remediation required. Access complies with least-privilege policy."
    if ($User.user_id -eq "U003" -and $severity -ne "Compliant") {
        $solution = "Disable 'tmorgan' immediately (contract expired 2026-11-01), revoke Server-Admins (G003) & All-Employees (G008), and audit server logs."
    }
    elseif ($User.user_id -eq "U001" -and $severity -ne "Compliant") {
        $solution = "Remove 'mtorres' from Payroll-Editors (G002); Support Reps are denied payroll edit rights. Audit payroll change logs."
    }
    elseif ($User.user_id -eq "U005" -and $severity -ne "Compliant") {
        $solution = "Remove 'spatel' from Finance-Reports (G005); Sales Reps are denied financial reporting portal access."
    }
    elseif ($User.user_id -eq "U012" -and $severity -ne "Compliant") {
        $solution = "Strip residual groups Sales-Reports (G004) & All-Employees (G008) from disabled former employee 'dreed'."
    }
    elseif ($User.user_id -eq "U008") {
        $solution = "Validated Exception: Ticket APR-2026-014 authorizes Finance-Reports (G005) through 2026-12-15. Review before expiration."
    }
    elseif ($severity -ne "Compliant") {
        $solution = "Revoke unauthorized group memberships and align account status with HR records."
    }

    return [PSCustomObject]@{
        Severity = $severity
        SevRank  = $sevRank
        Findings = ($findings -join " | ")
        Solution = $solution
    }
}

function Invoke-UserRemediation {
    param([string]$UserId)
    $u = $script:Users | Where-Object { $_.user_id -eq $UserId }
    if (-not $u) { return }

    if ($UserId -eq "U003") {
        $u.enabled = $false
        $toRemove = @($script:Memberships | Where-Object { $_.user_id -eq "U003" })
        foreach ($item in $toRemove) { [void]$script:Memberships.Remove($item) }
        if ($script:LiveADMode -and $script:HasADModule) {
            Disable-ADAccount -Identity "tmorgan" -ErrorAction SilentlyContinue
            Remove-ADGroupMember -Identity "Server-Admins" -Members "tmorgan" -Confirm:$false -ErrorAction SilentlyContinue
            Remove-ADGroupMember -Identity "All-Employees" -Members "tmorgan" -Confirm:$false -ErrorAction SilentlyContinue
        }
    }
    elseif ($UserId -eq "U001") {
        $toRemove = @($script:Memberships | Where-Object { $_.user_id -eq "U001" -and $_.group_id -eq "G002" })
        foreach ($item in $toRemove) { [void]$script:Memberships.Remove($item) }
        if ($script:LiveADMode -and $script:HasADModule) {
            Remove-ADGroupMember -Identity "Payroll-Editors" -Members "mtorres" -Confirm:$false -ErrorAction SilentlyContinue
        }
    }
    elseif ($UserId -eq "U005") {
        $toRemove = @($script:Memberships | Where-Object { $_.user_id -eq "U005" -and $_.group_id -eq "G005" })
        foreach ($item in $toRemove) { [void]$script:Memberships.Remove($item) }
        if ($script:LiveADMode -and $script:HasADModule) {
            Remove-ADGroupMember -Identity "Finance-Reports" -Members "spatel" -Confirm:$false -ErrorAction SilentlyContinue
        }
    }
    elseif ($UserId -eq "U012") {
        $u.enabled = $false
        $toRemove = @($script:Memberships | Where-Object { $_.user_id -eq "U012" })
        foreach ($item in $toRemove) { [void]$script:Memberships.Remove($item) }
        if ($script:LiveADMode -and $script:HasADModule) {
            Disable-ADAccount -Identity "dreed" -ErrorAction SilentlyContinue
            Remove-ADGroupMember -Identity "Sales-Reports" -Members "dreed" -Confirm:$false -ErrorAction SilentlyContinue
            Remove-ADGroupMember -Identity "All-Employees" -Members "dreed" -Confirm:$false -ErrorAction SilentlyContinue
        }
    }
    else {
        # Generic remediation for any custom violation created during testing
        $uMembs = @($script:Memberships | Where-Object { $_.user_id -eq $UserId })
        foreach ($m in $uMembs) {
            $pol = $script:Policies | Where-Object { $_.role -eq $u.role -and $_.group_id -eq $m.group_id }
            if ($pol -and $pol.access_decision -eq "Denied") {
                [void]$script:Memberships.Remove($m)
            }
        }
    }
}

# ==============================================================================
# 3. BUILD TRADITIONAL WINDOWS MMC 3.0 / ADUC DESKTOP FORM
# ==============================================================================
$form = New-Object System.Windows.Forms.Form
$form.Text = "Active Directory Users and Computers - [eaglebusiness.local] (PriVis Governance Edition)"
$form.Size = New-Object System.Drawing.Size(1240, 780)
$form.StartPosition = "CenterScreen"
$form.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$form.BackColor = [System.Drawing.SystemColors]::Control

# --- Classic MMC MenuStrip ---
$menuStrip = New-Object System.Windows.Forms.MenuStrip
$menuStrip.BackColor = [System.Drawing.SystemColors]::MenuBar

$menuFile = New-Object System.Windows.Forms.ToolStripMenuItem("&File")
$miExportPS = New-Object System.Windows.Forms.ToolStripMenuItem("Export Active Directory PowerShell Script (.ps1)...")
$miResetLab = New-Object System.Windows.Forms.ToolStripMenuItem("Reset VM Lab Dataset to Baseline")
$miExit     = New-Object System.Windows.Forms.ToolStripMenuItem("E&xit")
[void]$menuFile.DropDownItems.AddRange(@($miExportPS, $miResetLab, (New-Object System.Windows.Forms.ToolStripSeparator), $miExit))

$menuAction = New-Object System.Windows.Forms.ToolStripMenuItem("&Action")
$miRemediateSel = New-Object System.Windows.Forms.ToolStripMenuItem("Apply PriVis Solution to Selected User")
$miRemediateAll = New-Object System.Windows.Forms.ToolStripMenuItem("Remediate All At-Risk Accounts Now")
$miProvisionAD  = New-Object System.Windows.Forms.ToolStripMenuItem("Deploy OUs, Groups & Users to Local Active Directory...")
[void]$menuAction.DropDownItems.AddRange(@($miRemediateSel, $miRemediateAll, (New-Object System.Windows.Forms.ToolStripSeparator), $miProvisionAD))

$menuView = New-Object System.Windows.Forms.ToolStripMenuItem("&View")
$miShowAll = New-Object System.Windows.Forms.ToolStripMenuItem("Select Root Container (Eagle Business Solutions)")
[void]$menuView.DropDownItems.Add($miShowAll)

$menuHelp = New-Object System.Windows.Forms.ToolStripMenuItem("&Help")
$miAbout = New-Object System.Windows.Forms.ToolStripMenuItem("About PriVis ADUC Console...")
[void]$menuHelp.DropDownItems.Add($miAbout)

[void]$menuStrip.Items.AddRange(@($menuFile, $menuAction, $menuView, $menuHelp))
$form.MainMenuStrip = $menuStrip
$form.Controls.Add($menuStrip)

# --- Classic MMC ToolStrip ---
$toolStrip = New-Object System.Windows.Forms.ToolStrip
$toolStrip.GripStyle = "Hidden"
$toolStrip.BackColor = [System.Drawing.SystemColors]::Control

$btnRefresh   = New-Object System.Windows.Forms.ToolStripButton("Refresh")
$btnProps     = New-Object System.Windows.Forms.ToolStripButton("Properties")
$btnFixSel    = New-Object System.Windows.Forms.ToolStripButton("Apply Solution (Selected)")
$btnFixAll    = New-Object System.Windows.Forms.ToolStripButton("Remediate All Risks")
$btnReset     = New-Object System.Windows.Forms.ToolStripButton("Reset Lab")
$lblModeBadge = New-Object System.Windows.Forms.ToolStripLabel("Mode: VM Simulation Sandbox (RSAT AD Detected: $script:HasADModule)")
$lblModeBadge.ForeColor = [System.Drawing.Color]::DarkBlue

[void]$toolStrip.Items.AddRange(@(
    $btnRefresh,
    $btnProps,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $btnFixSel,
    $btnFixAll,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $btnReset,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $lblModeBadge
))
$form.Controls.Add($toolStrip)

# --- StatusStrip at Bottom ---
$statusStrip = New-Object System.Windows.Forms.StatusStrip
$statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel("Ready | Domain: eaglebusiness.local | Audit Date: 2026-11-14")
[void]$statusStrip.Items.Add($statusLabel)
$form.Controls.Add($statusStrip)

# --- Main SplitContainer (Left: AD TreeView | Right: Object List + Container Summary & Solutions) ---
$mainSplit = New-Object System.Windows.Forms.SplitContainer
$mainSplit.Dock = "Fill"
$mainSplit.SplitterDistance = 270
$mainSplit.BorderStyle = "Fixed3D"
$form.Controls.Add($mainSplit)
$mainSplit.BringToFront()

# Left Pane: MMC TreeView
$lblTreeHeader = New-Object System.Windows.Forms.Label
$lblTreeHeader.Text = " Active Directory Users and Computers"
$lblTreeHeader.Dock = "Top"
$lblTreeHeader.Height = 24
$lblTreeHeader.TextAlign = "MiddleLeft"
$lblTreeHeader.BackColor = [System.Drawing.SystemColors]::ControlDark
$lblTreeHeader.ForeColor = [System.Drawing.Color]::White
$lblTreeHeader.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)

$treeView = New-Object System.Windows.Forms.TreeView
$treeView.Dock = "Fill"
$treeView.HideSelection = $false
$treeView.ShowLines = $true
$treeView.ShowPlusMinus = $true
$treeView.ShowRootLines = $true
$treeView.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

$mainSplit.Panel1.Controls.Add($treeView)
$mainSplit.Panel1.Controls.Add($lblTreeHeader)

# Right Pane Split: Top = ADUC ListView | Bottom = Container Summary with Solutions Box
$rightSplit = New-Object System.Windows.Forms.SplitContainer
$rightSplit.Dock = "Fill"
$rightSplit.Orientation = "Horizontal"
$rightSplit.SplitterDistance = 370
$rightSplit.BorderStyle = "Fixed3D"
$mainSplit.Panel2.Controls.Add($rightSplit)

# Top Right Header Banner (Shows Selected Container & Department Color)
$lblContainerBanner = New-Object System.Windows.Forms.Label
$lblContainerBanner.Text = "  eaglebusiness.local / Eagle Business Solutions"
$lblContainerBanner.Dock = "Top"
$lblContainerBanner.Height = 28
$lblContainerBanner.TextAlign = "MiddleLeft"
$lblContainerBanner.Font = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold)
$lblContainerBanner.BackColor = [System.Drawing.SystemColors]::InactiveCaption

# Top Right ListView (Classic ADUC Columns)
$listView = New-Object System.Windows.Forms.ListView
$listView.Dock = "Fill"
$listView.View = "Details"
$listView.FullRowSelect = $true
$listView.GridLines = $true
$listView.MultiSelect = $false
$listView.Font = New-Object System.Drawing.Font("Segoe UI", 9)

[void]$listView.Columns.Add("Name", 150)
[void]$listView.Columns.Add("Type / Role", 145)
[void]$listView.Columns.Add("Department OU", 130)
[void]$listView.Columns.Add("Status", 95)
[void]$listView.Columns.Add("PriVis Risk", 95)
[void]$listView.Columns.Add("Group Memberships & Policy Findings", 330)

$rightSplit.Panel1.Controls.Add($listView)
$rightSplit.Panel1.Controls.Add($lblContainerBanner)

# ==============================================================================
# 4. CONTAINER SUMMARY PANEL + DEDICATED "SOLUTIONS" GROUPBOX
# ==============================================================================
$grpContainerSummary = New-Object System.Windows.Forms.GroupBox
$grpContainerSummary.Text = "Container Summary"
$grpContainerSummary.Dock = "Fill"
$grpContainerSummary.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$grpContainerSummary.Padding = New-Object System.Windows.Forms.Padding(8)
$rightSplit.Panel2.Controls.Add($grpContainerSummary)

$summarySplit = New-Object System.Windows.Forms.SplitContainer
$summarySplit.Dock = "Fill"
$summarySplit.SplitterDistance = 320
$grpContainerSummary.Controls.Add($summarySplit)

# Left side of Container Summary: Container Stats & Dept Color Legend
$txtContainerStats = New-Object System.Windows.Forms.RichTextBox
$txtContainerStats.Dock = "Fill"
$txtContainerStats.ReadOnly = $true
$txtContainerStats.BackColor = [System.Drawing.SystemColors]::Window
$txtContainerStats.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$txtContainerStats.BorderStyle = "FixedSingle"
$summarySplit.Panel1.Controls.Add($txtContainerStats)

# Right side of Container Summary: Dedicated "Solutions" GroupBox
$grpSolutions = New-Object System.Windows.Forms.GroupBox
$grpSolutions.Text = "Solutions (At-Risk Remediation Playbook)"
$grpSolutions.Dock = "Fill"
$grpSolutions.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$grpSolutions.ForeColor = [System.Drawing.Color]::DarkRed
$summarySplit.Panel2.Controls.Add($grpSolutions)

# Interactive Solutions ListView inside the Solutions Box
$lvSolutions = New-Object System.Windows.Forms.ListView
$lvSolutions.Dock = "Fill"
$lvSolutions.View = "Details"
$lvSolutions.FullRowSelect = $true
$lvSolutions.GridLines = $true
$lvSolutions.Font = New-Object System.Drawing.Font("Segoe UI", 8.5)
$lvSolutions.ForeColor = [System.Drawing.Color]::Black

[void]$lvSolutions.Columns.Add("Severity", 75)
[void]$lvSolutions.Columns.Add("At-Risk Account", 145)
[void]$lvSolutions.Columns.Add("Department", 110)
[void]$lvSolutions.Columns.Add("Recommended Solution", 360)

$pnlSolActions = New-Object System.Windows.Forms.Panel
$pnlSolActions.Dock = "Bottom"
$pnlSolActions.Height = 32

$btnApplySelectedSolution = New-Object System.Windows.Forms.Button
$btnApplySelectedSolution.Text = "Execute Highlighted Solution"
$btnApplySelectedSolution.Width = 195
$btnApplySelectedSolution.Height = 25
$btnApplySelectedSolution.Location = New-Object System.Drawing.Point(4, 4)
$btnApplySelectedSolution.Font = New-Object System.Drawing.Font("Segoe UI", 8.5, [System.Drawing.FontStyle]::Bold)
$btnApplySelectedSolution.ForeColor = [System.Drawing.Color]::Black

$btnApplyAllSolutions = New-Object System.Windows.Forms.Button
$btnApplyAllSolutions.Text = "Execute All At-Risk Solutions"
$btnApplyAllSolutions.Width = 195
$btnApplyAllSolutions.Height = 25
$btnApplyAllSolutions.Location = New-Object System.Drawing.Point(206, 4)
$btnApplyAllSolutions.Font = New-Object System.Drawing.Font("Segoe UI", 8.5)
$btnApplyAllSolutions.ForeColor = [System.Drawing.Color]::Black

[void]$pnlSolActions.Controls.AddRange(@($btnApplySelectedSolution, $btnApplyAllSolutions))
[void]$grpSolutions.Controls.Add($lvSolutions)
[void]$grpSolutions.Controls.Add($pnlSolActions)

# ==============================================================================
# 5. POPULATE TREEVIEW & REFRESH VIEWS
# ==============================================================================
function Build-ADTree {
    $treeView.Nodes.Clear()
    $rootNode = New-Object System.Windows.Forms.TreeNode("Active Directory Users and Computers [eaglebusiness.local]")
    $rootNode.Tag = "ROOT_DOMAIN"

    $domainNode = New-Object System.Windows.Forms.TreeNode("eaglebusiness.local")
    $domainNode.Tag = "ROOT_DOMAIN"

    $companyNode = New-Object System.Windows.Forms.TreeNode("Eagle Business Solutions (All Containers)")
    $companyNode.Tag = "ALL_COMPANY"
    $companyNode.NodeFont = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold)

    $ouOrder = @("Customer Support", "IT", "Sales", "Finance", "HR", "Security Groups")
    foreach ($ouName in $ouOrder) {
        $ouNode = New-Object System.Windows.Forms.TreeNode("OU=$ouName")
        $ouNode.Tag = $ouName
        $ouNode.BackColor = $DeptColors[$ouName]
        [void]$companyNode.Nodes.Add($ouNode)
    }

    [void]$domainNode.Nodes.Add($companyNode)
    [void]$rootNode.Nodes.Add($domainNode)
    [void]$treeView.Nodes.Add($rootNode)

    $rootNode.ExpandAll()
    $treeView.SelectedNode = $companyNode
}

function Refresh-ConsoleView {
    $selectedTag = if ($treeView.SelectedNode) { $treeView.SelectedNode.Tag } else { "ALL_COMPANY" }
    $listView.Items.Clear()
    $lvSolutions.Items.Clear()

    # Update Banner Color & Text
    if ($DeptColors.ContainsKey($selectedTag)) {
        $lblContainerBanner.BackColor = $DeptColors[$selectedTag]
        $lblContainerBanner.Text = "  Container: OU=$selectedTag,OU=Eagle Business Solutions,DC=eaglebusiness,DC=local"
    } else {
        $lblContainerBanner.BackColor = [System.Drawing.SystemColors]::InactiveCaption
        $lblContainerBanner.Text = "  Container: OU=Eagle Business Solutions,DC=eaglebusiness,DC=local (All Departmental OUs)"
    }

    # Filter Users or Security Groups
    $scopedUsers = @()
    if ($selectedTag -eq "Security Groups") {
        foreach ($g in $script:Groups) {
            $members = @($script:Memberships | Where-Object { $_.group_id -eq $g.group_id } | ForEach-Object {
                $uid = $_.user_id
                ($script:Users | Where-Object { $_.user_id -eq $uid }).sam
            })
            $lvi = New-Object System.Windows.Forms.ListViewItem("$($g.group_name) ($($g.group_id))")
            [void]$lvi.SubItems.Add("Global Security Group")
            [void]$lvi.SubItems.Add("Security Groups")
            [void]$lvi.SubItems.Add("Risk: $($g.risk_level)")
            [void]$lvi.SubItems.Add($g.risk_level)
            [void]$lvi.SubItems.Add("Members ($($members.Count)): $($members -join ', ') | $($g.resource_scope)")
            $lvi.BackColor = $DeptColors["Security Groups"]
            $lvi.Tag = $g
            [void]$listView.Items.Add($lvi)
        }
    }
    else {
        $scopedUsers = if ($selectedTag -in @("ROOT_DOMAIN", "ALL_COMPANY")) {
            $script:Users
        } else {
            @($script:Users | Where-Object { $_.dept -eq $selectedTag })
        }

        foreach ($u in $scopedUsers) {
            $risk = Get-UserRiskAnalysis -User $u
            $uGroups = @($script:Memberships | Where-Object { $_.user_id -eq $u.user_id } | ForEach-Object {
                $gid = $_.group_id
                ($script:Groups | Where-Object { $_.group_id -eq $gid }).group_name
            })
            $statusTxt = if ($u.enabled) { "Enabled" } else { "Disabled" }
            $detailTxt = if ($risk.Findings) { "Groups: [$($uGroups -join ', ')] - $($risk.Findings)" } else { "Groups: [$($uGroups -join ', ')] - Policy Compliant" }

            $lvi = New-Object System.Windows.Forms.ListViewItem("$($u.name) ($($u.sam))")
            [void]$lvi.SubItems.Add("$($u.role) [$($u.worker_type)]")
            [void]$lvi.SubItems.Add($u.dept)
            [void]$lvi.SubItems.Add($statusTxt)
            [void]$lvi.SubItems.Add($risk.Severity)
            [void]$lvi.SubItems.Add($detailTxt)

            # Department Color Highlighting on Row
            $lvi.BackColor = $DeptColors[$u.dept]
            if ($risk.Severity -eq "Critical") { $lvi.ForeColor = [System.Drawing.Color]::DarkRed; $lvi.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold) }
            elseif ($risk.Severity -eq "High") { $lvi.ForeColor = [System.Drawing.Color]::FromArgb(154, 52, 18); $lvi.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold) }
            elseif ($risk.Severity -eq "Medium") { $lvi.ForeColor = [System.Drawing.Color]::FromArgb(133, 77, 14) }
            elseif (-not $u.enabled) { $lvi.ForeColor = [System.Drawing.Color]::DimGray }

            $lvi.Tag = $u
            [void]$listView.Items.Add($lvi)
        }
    }

    # Populate Container Summary Text
    $allTargetUsers = if ($selectedTag -in @("ROOT_DOMAIN", "ALL_COMPANY", "Security Groups")) { $script:Users } else { $scopedUsers }
    $totalCount     = $allTargetUsers.Count
    $enabledCount   = @($allTargetUsers | Where-Object { $_.enabled }).Count
    $atRiskList     = @()
    foreach ($u in $allTargetUsers) {
        $r = Get-UserRiskAnalysis -User $u
        if ($r.Severity -ne "Compliant") {
            $atRiskList += [PSCustomObject]@{ User = $u; Risk = $r }
        }
    }
    $atRiskList = $atRiskList | Sort-Object { $_.Risk.SevRank } -Descending

    $txtContainerStats.Clear()
    $txtContainerStats.SelectionFont = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold)
    $txtContainerStats.AppendText("Selected OU: $selectedTag`r`n")
    $txtContainerStats.SelectionFont = New-Object System.Drawing.Font("Segoe UI", 9)
    $txtContainerStats.AppendText("Total User Objects: $totalCount  |  Enabled: $enabledCount  |  At-Risk: $($atRiskList.Count)`r`n")
    $txtContainerStats.AppendText("--------------------------------------------------`r`n")
    $txtContainerStats.SelectionFont = New-Object System.Drawing.Font("Segoe UI", 8.5, [System.Drawing.FontStyle]::Bold)
    $txtContainerStats.AppendText("Department Color Legend:`r`n")
    $txtContainerStats.SelectionFont = New-Object System.Drawing.Font("Segoe UI", 8.5)
    $txtContainerStats.AppendText("  * Customer Support: Teal   * IT: Royal Blue`r`n")
    $txtContainerStats.AppendText("  * Sales: Amber             * Finance: Emerald`r`n")
    $txtContainerStats.AppendText("  * HR: Purple               * Security Groups: Slate`r`n")

    # Populate Dedicated Solutions Box
    if ($atRiskList.Count -eq 0) {
        $sItem = New-Object System.Windows.Forms.ListViewItem("OK")
        [void]$sItem.SubItems.Add("All Accounts Compliant")
        [void]$sItem.SubItems.Add($selectedTag)
        [void]$sItem.SubItems.Add("Zero least-privilege violations detected in this container.")
        $sItem.BackColor = [System.Drawing.Color]::FromArgb(220, 252, 231)
        [void]$lvSolutions.Items.Add($sItem)
        $btnApplySelectedSolution.Enabled = $false
        $btnApplyAllSolutions.Enabled = $false
    }
    else {
        $btnApplySelectedSolution.Enabled = $true
        $btnApplyAllSolutions.Enabled = $true
        foreach ($entry in $atRiskList) {
            $u = $entry.User
            $r = $entry.Risk
            $sItem = New-Object System.Windows.Forms.ListViewItem($r.Severity.ToUpper())
            [void]$sItem.SubItems.Add("$($u.name) ($($u.sam))")
            [void]$sItem.SubItems.Add($u.dept)
            [void]$sItem.SubItems.Add($r.Solution)
            $sItem.Tag = $u.user_id

            if ($r.Severity -eq "Critical") { $sItem.BackColor = [System.Drawing.Color]::FromArgb(254, 226, 226) }
            elseif ($r.Severity -eq "High") { $sItem.BackColor = [System.Drawing.Color]::FromArgb(255, 237, 213) }
            elseif ($r.Severity -eq "Medium") { $sItem.BackColor = [System.Drawing.Color]::FromArgb(254, 249, 195) }
            else { $sItem.BackColor = [System.Drawing.Color]::FromArgb(224, 242, 254) }

            [void]$lvSolutions.Items.Add($sItem)
        }
        $lvSolutions.Items[0].Selected = $true
    }

    $statusLabel.Text = "Container: $selectedTag | Objects: $($listView.Items.Count) | Active At-Risk Items: $($atRiskList.Count) | Audit Date: 2026-11-14"
}

# ==============================================================================
# 6. TRADITIONAL WINDOWS PROPERTIES DIALOG (DOUBLE-CLICK USER)
# ==============================================================================
function Show-UserPropertiesDialog {
    param($User)
    if (-not $User -or -not $User.user_id) { return }
    $risk = Get-UserRiskAnalysis -User $User

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($User.name) Properties"
    $dlg.Size = New-Object System.Drawing.Size(470, 440)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false

    $tabs = New-Object System.Windows.Forms.TabControl
    $tabs.Location = New-Object System.Drawing.Point(10, 10)
    $tabs.Size = New-Object System.Drawing.Size(434, 345)

    # Tab 1: General & Account
    $tabGen = New-Object System.Windows.Forms.TabPage("General & Account")
    $tabGen.BackColor = $DeptColors[$User.dept]
    $lblGen = New-Object System.Windows.Forms.Label
    $lblGen.Location = New-Object System.Drawing.Point(14, 14)
    $lblGen.Size = New-Object System.Drawing.Size(395, 285)
    $lblGen.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
    $lblGen.Text = @"
Display Name:       $($User.name)
User ID:            $($User.user_id)
Logon Name:         $($User.sam)@eaglebusiness.local
Department OU:      OU=$($User.dept),OU=Eagle Business Solutions
Job Role:           $($User.role)
Worker Type:        $($User.worker_type)
Account Status:     $(if ($User.enabled) { 'Enabled (Active)' } else { 'Disabled' })
Contract End Date:  $(if ($User.end_date) { $User.end_date } else { 'Never (Permanent)' })
"@
    [void]$tabGen.Controls.Add($lblGen)

    # Tab 2: Member Of (Interactive Add/Remove Groups for VM Testing)
    $tabMem = New-Object System.Windows.Forms.TabPage("Member Of")
    $lbGroups = New-Object System.Windows.Forms.ListBox
    $lbGroups.Location = New-Object System.Drawing.Point(12, 14)
    $lbGroups.Size = New-Object System.Drawing.Size(400, 210)
    foreach ($m in ($script:Memberships | Where-Object { $_.user_id -eq $User.user_id })) {
        $g = $script:Groups | Where-Object { $_.group_id -eq $m.group_id }
        [void]$lbGroups.Items.Add("$($g.group_id) - $($g.group_name) [Risk: $($g.risk_level)]")
    }

    $cmbAddGroup = New-Object System.Windows.Forms.ComboBox
    $cmbAddGroup.Location = New-Object System.Drawing.Point(12, 236)
    $cmbAddGroup.Size = New-Object System.Drawing.Size(220, 24)
    $cmbAddGroup.DropDownStyle = "DropDownList"
    foreach ($g in $script:Groups) { [void]$cmbAddGroup.Items.Add("$($g.group_id) - $($g.group_name)") }
    $cmbAddGroup.SelectedIndex = 0

    $btnAddGrp = New-Object System.Windows.Forms.Button
    $btnAddGrp.Text = "Add Group"
    $btnAddGrp.Location = New-Object System.Drawing.Point(240, 235)
    $btnAddGrp.Size = New-Object System.Drawing.Size(80, 25)
    $btnAddGrp.Add_Click({
        $selGid = $cmbAddGroup.SelectedItem.ToString().Split(" ")[0]
        $exists = $script:Memberships | Where-Object { $_.user_id -eq $User.user_id -and $_.group_id -eq $selGid }
        if (-not $exists) {
            [void]$script:Memberships.Add([PSCustomObject]@{
                user_id = $User.user_id; group_id = $selGid; approval_status = "Missing"; approval_ticket = $null; approval_expires = $null
            })
            $gObj = $script:Groups | Where-Object { $_.group_id -eq $selGid }
            [void]$lbGroups.Items.Add("$($gObj.group_id) - $($gObj.group_name) [Risk: $($gObj.risk_level)]")
            Refresh-ConsoleView
        }
    })

    $btnRemGrp = New-Object System.Windows.Forms.Button
    $btnRemGrp.Text = "Remove"
    $btnRemGrp.Location = New-Object System.Drawing.Point(326, 235)
    $btnRemGrp.Size = New-Object System.Drawing.Size(86, 25)
    $btnRemGrp.Add_Click({
        if ($lbGroups.SelectedItem) {
            $selGid = $lbGroups.SelectedItem.ToString().Split(" ")[0]
            $target = $script:Memberships | Where-Object { $_.user_id -eq $User.user_id -and $_.group_id -eq $selGid }
            if ($target) { [void]$script:Memberships.Remove($target) }
            $lbGroups.Items.Remove($lbGroups.SelectedItem)
            Refresh-ConsoleView
        }
    })
    [void]$tabMem.Controls.AddRange(@($lbGroups, $cmbAddGroup, $btnAddGrp, $btnRemGrp))

    # Tab 3: PriVis Audit & Solution
    $tabPriv = New-Object System.Windows.Forms.TabPage("PriVis Solution")
    $txtPriv = New-Object System.Windows.Forms.TextBox
    $txtPriv.Multiline = $true
    $txtPriv.ReadOnly = $true
    $txtPriv.Location = New-Object System.Drawing.Point(12, 14)
    $txtPriv.Size = New-Object System.Drawing.Size(400, 240)
    $txtPriv.Text = "Risk Level: $($risk.Severity)`r`n`r`nFindings:`r`n$($risk.Findings)`r`n`r`nRecommended Solution:`r`n$($risk.Solution)"

    $btnDlgFix = New-Object System.Windows.Forms.Button
    $btnDlgFix.Text = "Apply PriVis Remediation Now"
    $btnDlgFix.Location = New-Object System.Drawing.Point(12, 265)
    $btnDlgFix.Size = New-Object System.Drawing.Size(210, 28)
    $btnDlgFix.Enabled = ($risk.Severity -ne "Compliant")
    $btnDlgFix.Add_Click({
        Invoke-UserRemediation -UserId $User.user_id
        Refresh-ConsoleView
        $dlg.Close()
    })
    [void]$tabPriv.Controls.AddRange(@($txtPriv, $btnDlgFix))

    [void]$tabs.TabPages.AddRange(@($tabGen, $tabMem, $tabPriv))
    [void]$dlg.Controls.Add($tabs)

    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = "OK"
    $btnOK.Location = New-Object System.Drawing.Point(369, 365)
    $btnOK.Add_Click({ $dlg.Close() })
    [void]$dlg.Controls.Add($btnOK)

    [void]$dlg.ShowDialog()
}

# ==============================================================================
# 7. WIRE EVENT HANDLERS
# ==============================================================================
$treeView.Add_AfterSelect({ Refresh-ConsoleView })
$btnRefresh.Add_Click({ Refresh-ConsoleView })
$miShowAll.Add_Click({ $treeView.SelectedNode = $treeView.Nodes[0].Nodes[0].Nodes[0] })

$listView.Add_DoubleClick({
    if ($listView.SelectedItems.Count -gt 0) {
        $obj = $listView.SelectedItems[0].Tag
        if ($obj.user_id) { Show-UserPropertiesDialog -User $obj }
    }
})

$btnProps.Add_Click({
    if ($listView.SelectedItems.Count -gt 0) {
        $obj = $listView.SelectedItems[0].Tag
        if ($obj.user_id) { Show-UserPropertiesDialog -User $obj }
    }
})

$applySelectedHandler = {
    if ($lvSolutions.SelectedItems.Count -gt 0 -and $lvSolutions.SelectedItems[0].Tag) {
        $uid = $lvSolutions.SelectedItems[0].Tag
        Invoke-UserRemediation -UserId $uid
        Refresh-ConsoleView
    }
    elseif ($listView.SelectedItems.Count -gt 0 -and $listView.SelectedItems[0].Tag.user_id) {
        Invoke-UserRemediation -UserId $listView.SelectedItems[0].Tag.user_id
        Refresh-ConsoleView
    }
}
$btnApplySelectedSolution.Add_Click($applySelectedHandler)
$btnFixSel.Add_Click($applySelectedHandler)
$miRemediateSel.Add_Click($applySelectedHandler)

$applyAllHandler = {
    foreach ($u in $script:Users) {
        $r = Get-UserRiskAnalysis -User $u
        if ($r.Severity -ne "Compliant") {
            Invoke-UserRemediation -UserId $u.user_id
        }
    }
    Refresh-ConsoleView
    [System.Windows.Forms.MessageBox]::Show("All 4 at-risk accounts have been remediated according to least-privilege policy.", "PriVis Remediation Complete", "OK", "Information")
}
$btnApplyAllSolutions.Add_Click($applyAllHandler)
$btnFixAll.Add_Click($applyAllHandler)
$miRemediateAll.Add_Click($applyAllHandler)

$resetHandler = {
    Reset-LabState
    Refresh-ConsoleView
}
$btnReset.Add_Click($resetHandler)
$miResetLab.Add_Click($resetHandler)

$miProvisionAD.Add_Click({
    if (-not $script:HasADModule) {
        [System.Windows.Forms.MessageBox]::Show(
            "The Windows ActiveDirectory PowerShell module (RSAT) was not detected on this VM.`n`nTo deploy into a real Windows Server Domain Controller:`n1. Install RSAT-AD-PowerShell or run on your Domain Controller.`n2. Run the companion script 'EagleBusiness_AD_Provisioning_and_Remediation.ps1'.`n`nYou can continue testing all ADUC containers, group changes, and solutions in Sandbox Mode right now.",
            "Active Directory Module Not Installed", "OK", "Warning")
    } else {
        $script:LiveADMode = $true
        $lblModeBadge.Text = "Mode: LIVE ACTIVE DIRECTORY CONNECTED"
        $lblModeBadge.ForeColor = [System.Drawing.Color]::DarkGreen
        [System.Windows.Forms.MessageBox]::Show("Connected to local Active Directory Domain Services! Subsequent remediation actions will execute directly against AD.", "Live AD Connected", "OK", "Information")
    }
})

$miExportPS.Add_Click({
    $sfd = New-Object System.Windows.Forms.SaveFileDialog
    $sfd.Filter = "PowerShell Script (*.ps1)|*.ps1"
    $sfd.FileName = "PriVis_AD_Remediation_Export.ps1"
    if ($sfd.ShowDialog() -eq "OK") {
        $lines = @("# Generated by PriVis ADUC MMC Console on $(Get-Date -Format 'yyyy-MM-dd HH:mm')", "Import-Module ActiveDirectory")
        foreach ($u in $script:Users) {
            if (-not $u.enabled) { $lines += "Disable-ADAccount -Identity '$($u.sam)'" }
            $activeGrps = @($script:Memberships | Where-Object { $_.user_id -eq $u.user_id } | ForEach-Object {
                $gid = $_.group_id
                ($script:Groups | Where-Object { $_.group_id -eq $gid }).group_name
            })
            $lines += "# $($u.name) ($($u.dept) - $($u.role)): Active Groups = $($activeGrps -join ', ')"
        }
        $lines -join "`r`n" | Out-File -FilePath $sfd.FileName -Encoding UTF8
        [System.Windows.Forms.MessageBox]::Show("Exported PowerShell commands to $($sfd.FileName)", "Export Complete", "OK", "Information")
    }
})

$miAbout.Add_Click({
    [System.Windows.Forms.MessageBox]::Show("PriVis Active Directory Users and Computers (MMC Edition)`nTarget Environment: Windows 10/11 / Windows Server (VMware Fusion)`nDomain: eaglebusiness.local", "About PriVis", "OK", "Information")
})

$miExit.Add_Click({ $form.Close() })

# Initialize and launch
Build-ADTree
[void]$form.ShowDialog()
