﻿<#
.SYNOPSIS
    Active Directory Organizational Unit, Security Group, User Provisioning,
    and PriVis Least-Privilege Remediation Script for Eagle Business Solutions.
.DESCRIPTION
    Target Domain: eaglebusiness.local
    Audit Date:    2026-11-14
#>
Import-Module ActiveDirectory

$DomainDN = "DC=eaglebusiness,DC=local"
$RootOU   = "OU=Eagle Business Solutions,$DomainDN"

if (-not (Get-ADOrganizationalUnit -Filter "DistinguishedName -eq '$RootOU'" -ErrorAction SilentlyContinue)) {
    New-ADOrganizationalUnit -Name "Eagle Business Solutions" -Path $DomainDN -Description "Primary corporate container for Eagle Business Solutions"
}

$Departments = @(
    @{ Name = "Customer Support"; Color = "Teal (#008080)";    Desc = "Customer Support Department Container" },
    @{ Name = "IT";               Color = "Blue (#005A9E)";    Desc = "Information Technology Department Container" },
    @{ Name = "Sales";            Color = "Amber (#B45309)";   Desc = "Sales Department Container" },
    @{ Name = "Finance";          Color = "Emerald (#047857)"; Desc = "Finance & Payroll Department Container" },
    @{ Name = "HR";               Color = "Purple (#6D28D9)";  Desc = "Human Resources Department Container" },
    @{ Name = "Security Groups";  Color = "Slate (#475569)";   Desc = "Global Security Groups Container" }
)

foreach ($dept in $Departments) {
    $ouDN = "OU=$($dept.Name),$RootOU"
    if (-not (Get-ADOrganizationalUnit -Filter "DistinguishedName -eq '$ouDN'" -ErrorAction SilentlyContinue)) {
        New-ADOrganizationalUnit -Name $dept.Name -Path $RootOU -Description "$($dept.Desc) [MMC Color: $($dept.Color)]"
    }
}

$GroupsOU = "OU=Security Groups,$RootOU"
$SecurityGroups = @(
    @{ Name = "Customer-Support"; Desc = "[G001 | Low] CRM - customer records" },
    @{ Name = "Payroll-Editors";  Desc = "[G002 | High] Payroll application" },
    @{ Name = "Server-Admins";    Desc = "[G003 | Critical] Server administration" },
    @{ Name = "Sales-Reports";    Desc = "[G004 | Low] Sales reporting portal" },
    @{ Name = "Finance-Reports";  Desc = "[G005 | Medium] Financial reporting portal" },
    @{ Name = "HR-Records";       Desc = "[G006 | High] HR records application" },
    @{ Name = "Helpdesk-Reset";   Desc = "[G007 | High] IT service desk" },
    @{ Name = "All-Employees";    Desc = "[G008 | Low] Company intranet" }
)

foreach ($grp in $SecurityGroups) {
    if (-not (Get-ADGroup -Filter "SamAccountName -eq '$($grp.Name)'" -ErrorAction SilentlyContinue)) {
        New-ADGroup -Name $grp.Name -SamAccountName $grp.Name -GroupScope Global -GroupCategory Security -Path $GroupsOU -Description $grp.Desc
    }
}

$DefaultPassword = ConvertTo-SecureString "TempP@ssw0rd2026!" -AsPlainText -Force
$Users = @(
    @{ Id="U001"; Name="Maya Torres";   Given="Maya";   Sur="Torres"; Sam="mtorres"; Dept="Customer Support"; Title="Support Rep";        Type="Part-Time";       Enabled=$true;  EndDate=$null },
    @{ Id="U002"; Name="Alex Chen";     Given="Alex";   Sur="Chen";   Sam="achen";   Dept="IT";               Title="IT Admin";           Type="Full-Time";       Enabled=$true;  EndDate=$null },
    @{ Id="U003"; Name="Taylor Morgan"; Given="Taylor"; Sur="Morgan"; Sam="tmorgan"; Dept="IT";               Title="IT Contractor";      Type="Contractor";      Enabled=$true;  EndDate="2026-11-01" },
    @{ Id="U004"; Name="Jordan Lee";    Given="Jordan"; Sur="Lee";    Sam="jlee";    Dept="Customer Support"; Title="Support Rep";        Type="Part-Time";       Enabled=$true;  EndDate=$null },
    @{ Id="U005"; Name="Sam Patel";     Given="Sam";    Sur="Patel";  Sam="spatel";  Dept="Sales";            Title="Sales Rep";          Type="Full-Time";       Enabled=$true;  EndDate=$null },
    @{ Id="U006"; Name="Chris Rivera";  Given="Chris";  Sur="Rivera"; Sam="crivera"; Dept="Finance";          Title="Finance Analyst";    Type="Full-Time";       Enabled=$true;  EndDate=$null },
    @{ Id="U007"; Name="Renee Brooks";  Given="Renee";  Sur="Brooks"; Sam="rbrooks"; Dept="Finance";          Title="Payroll Specialist"; Type="Full-Time";       Enabled=$true;  EndDate=$null },
    @{ Id="U008"; Name="Avery Kim";     Given="Avery";  Sur="Kim";    Sam="akim";    Dept="Sales";            Title="Sales Manager";      Type="Full-Time";       Enabled=$true;  EndDate=$null },
    @{ Id="U009"; Name="Morgan Ellis";  Given="Morgan"; Sur="Ellis";  Sam="mellis";  Dept="HR";               Title="HR Coordinator";     Type="Full-Time";       Enabled=$true;  EndDate=$null },
    @{ Id="U010"; Name="Jamie Price";   Given="Jamie";  Sur="Price";  Sam="jprice";  Dept="IT";               Title="IT Support";         Type="Full-Time";       Enabled=$true;  EndDate=$null },
    @{ Id="U011"; Name="Casey Nguyen";  Given="Casey";  Sur="Nguyen"; Sam="cnguyen"; Dept="Finance";          Title="Finance Manager";    Type="Full-Time";       Enabled=$true;  EndDate=$null },
    @{ Id="U012"; Name="Devon Reed";    Given="Devon";  Sur="Reed";   Sam="dreed";   Dept="Sales";            Title="Sales Rep";          Type="Former Employee"; Enabled=$false; EndDate="2026-09-30" }
)

foreach ($u in $Users) {
    $userOU = "OU=$($u.Dept),$RootOU"
    if (-not (Get-ADUser -Filter "SamAccountName -eq '$($u.Sam)'" -ErrorAction SilentlyContinue)) {
        New-ADUser -Name $u.Name -GivenName $u.Given -Surname $u.Sur -SamAccountName $u.Sam `
            -UserPrincipalName "$($u.Sam)@eaglebusiness.local" -Department $u.Dept -Title $u.Title `
            -EmployeeID $u.Id -Description "$($u.Type) | $($u.Title)" -Path $userOU `
            -AccountPassword $DefaultPassword -Enabled $u.Enabled
    }
    if ($u.EndDate) { Set-ADAccountExpiration -Identity $u.Sam -DateTime ([datetime]$u.EndDate) }
}

# Enforce Least-Privilege Memberships
Add-ADGroupMember -Identity "Customer-Support" -Members "mtorres", "jlee"
Add-ADGroupMember -Identity "All-Employees"    -Members "mtorres", "achen", "jlee", "spatel", "crivera", "rbrooks", "akim", "mellis", "jprice", "cnguyen"
Add-ADGroupMember -Identity "Server-Admins"    -Members "achen"
Add-ADGroupMember -Identity "Helpdesk-Reset"   -Members "achen", "jprice"
Add-ADGroupMember -Identity "Sales-Reports"    -Members "spatel", "akim"
Add-ADGroupMember -Identity "Finance-Reports"  -Members "crivera", "rbrooks", "akim", "cnguyen"
Add-ADGroupMember -Identity "Payroll-Editors"  -Members "rbrooks", "cnguyen"
Add-ADGroupMember -Identity "HR-Records"       -Members "mellis"

# PriVis Remediations
Disable-ADAccount -Identity "tmorgan"
Remove-ADGroupMember -Identity "Server-Admins"   -Members "tmorgan" -Confirm:$false
Remove-ADGroupMember -Identity "All-Employees"   -Members "tmorgan" -Confirm:$false
Remove-ADGroupMember -Identity "Payroll-Editors" -Members "mtorres" -Confirm:$false
Remove-ADGroupMember -Identity "Finance-Reports" -Members "spatel"  -Confirm:$false
Disable-ADAccount -Identity "dreed"
Remove-ADGroupMember -Identity "Sales-Reports"   -Members "dreed"   -Confirm:$false
Remove-ADGroupMember -Identity "All-Employees"   -Members "dreed"   -Confirm:$false
