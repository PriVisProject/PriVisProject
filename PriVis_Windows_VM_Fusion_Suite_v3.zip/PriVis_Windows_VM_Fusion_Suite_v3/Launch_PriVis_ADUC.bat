@echo off
title Launching PriVis Active Directory MMC Console...
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0PriVis_ADUC_Console.ps1"
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Console exited with code %ERRORLEVEL%.
    pause
)
